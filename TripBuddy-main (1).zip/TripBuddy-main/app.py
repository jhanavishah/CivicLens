"""
TripBuddy Flask Application - Main Controller
This is the main application file that handles all API routes
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime
import json
import time
import secrets

# Import from our modules
from config import (
    CORS_ORIGINS, CORS_METHODS, CORS_HEADERS, CORS_SUPPORTS_CREDENTIALS,
    FLASK_HOST, FLASK_PORT, FLASK_DEBUG, 
    otp_store, otp_resend_time, OTP_EXPIRY_TIME, OTP_RESEND_COOLDOWN,
    DEFAULT_USER_ID
)
from utils import generate_otp, send_otp_email, parse_date_range
from database import (
    get_db_connection, get_admin_by_email, get_user_by_email, get_user_by_id,
    create_user, update_user_profile, change_user_password, get_all_users, update_user_status,
    create_booking, get_user_bookings, get_all_bookings, update_booking_status, 
    cancel_booking, delete_booking,
    get_all_flights, get_flight_by_id, add_flight, update_flight, delete_flight,
    get_all_hotels, get_hotel_by_id, update_hotel, delete_hotel,
    get_all_packages, get_package_by_id, update_package, delete_package,
    get_all_trains, get_train_by_id, update_train, delete_train,
    add_saved_item, get_saved_items, delete_saved_item,
    get_admin_stats, get_analytics_data,
    create_contact_message, get_all_contact_messages, update_contact_message_status, delete_contact_message
)

# Initialize Flask app
app = Flask(__name__)

# Enable CORS for all routes with specific configuration
CORS(app, resources={r"/*": {
    "origins": CORS_ORIGINS,
    "methods": CORS_METHODS,
    "allow_headers": CORS_HEADERS,
    "supports_credentials": CORS_SUPPORTS_CREDENTIALS
}})


# ==================== SYSTEM ROUTES ====================
@app.route('/api/test-connection', methods=['GET'])
def test_connection():
    """Test database connection"""
    conn = get_db_connection()
    if conn:
        conn.close()
        return jsonify({'status': 'success', 'message': 'Database connection successful'}), 200
    else:
        return jsonify({'status': 'error', 'message': 'Database connection failed'}), 500


@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'ok'}), 200


# ==================== ADMIN ROUTES ====================
@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    """Admin login endpoint with password hashing"""
    try:
        data = request.json
        email = data.get('email', '').strip()
        password = data.get('password', '')
        
        print(f"Admin Login attempt - Email: {email}")
        
        if not email or not password:
            return jsonify({'success': False, 'message': 'Email and password required'}), 400

        admin = get_admin_by_email(email)
        
        if admin and check_password_hash(admin['password_hash'], password):
            # Generate a token
            token = secrets.token_urlsafe(32)
            print(f"Admin login successful for {email}")
            return jsonify({
                'success': True, 
                'message': 'Login successful',
                'token': token,
                'admin_id': admin['id'],
                'username': admin['username'],
                'email': admin['email']
            }), 200
        else:
            print(f"Admin login failed for {email}")
            return jsonify({'success': False, 'message': 'Invalid email or password'}), 401
            
    except Exception as e:
        print(f"Admin Login Error: {e}")
        return jsonify({'success': False, 'message': 'Server error during login'}), 500

@app.route('/api/admin/verify', methods=['POST'])
def verify_admin_token():
    """Verify admin token"""
    try:
        data = request.json
        token = data.get('token')
        
        if not token:
            return jsonify({'success': False, 'message': 'Token required'}), 400
        
        # For now, just verify the token exists and is valid length
        # In production, use proper JWT tokens
        if len(token) > 20:
            return jsonify({'success': True, 'message': 'Token valid'}), 200
        else:
            return jsonify({'success': False, 'message': 'Invalid token'}), 401
            
    except Exception as e:
        print(f"Token Verification Error: {e}")
        return jsonify({'success': False, 'message': 'Server error'}), 500

# ==================== OTP ROUTES ====================
@app.route('/send-otp', methods=['POST'])
def send_otp():
    """Send OTP to user's email"""
    print('--- /send-otp route called ---')
    data = request.json
    email = data.get('email')
    print(f'Received email for OTP: {email}')
    if not email:
        return jsonify({'success': False, 'message': 'Email required'}), 400
    
    now = time.time()
    if email in otp_resend_time and now - otp_resend_time[email] < OTP_RESEND_COOLDOWN:
        wait_time = int(OTP_RESEND_COOLDOWN - (now - otp_resend_time[email]))
        return jsonify({'success': False, 'message': f'Please wait {wait_time}s before retrying.'}), 429
    
    otp = generate_otp()
    otp_store[email] = {'otp': otp, 'timestamp': now}
    otp_resend_time[email] = now
    
    try:
        send_otp_email(email, otp)
        return jsonify({'success': True, 'message': 'OTP sent successfully'})
    except Exception as e:
        print(f'Error sending OTP email: {e}')
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/verify-otp', methods=['POST'])
def verify_otp():
    """Verify OTP for email verification"""
    data = request.json
    email = data.get('email')
    otp = data.get('otp')
    
    if not email or not otp:
        return jsonify({'success': False, 'message': 'Email and OTP required'}), 400
    
    otp_data = otp_store.get(email)
    if not otp_data:
        return jsonify({'success': False, 'message': 'No OTP found. Please request a new one.'}), 400
    
    now = time.time()
    if now - otp_data['timestamp'] > OTP_EXPIRY_TIME:
        del otp_store[email]
        return jsonify({'success': False, 'message': 'OTP expired. Request a new one.'}), 401
    
    if otp_data['otp'] == otp:
        del otp_store[email]
        return jsonify({'success': True, 'message': 'OTP verified successfully'})
    else:
        return jsonify({'success': False, 'message': 'Invalid OTP'}), 401

# ==================== LOGIN VALIDATION ROUTE ====================
@app.route('/api/validate-login', methods=['POST'])
def validate_login():
    """Validate user login credentials"""
    try:
        data = request.json
        email = data.get('email')
        password = data.get('password')
        
        print(f"[Login] Attempt for email: {email}")
        
        if not email or not password:
            return jsonify({'success': False, 'message': 'Email and password required'}), 400

        user = get_user_by_email(email)
        
        if user and check_password_hash(user['password_hash'], password):
            print(f"[Login] Success for email: {email}")
            return jsonify({'success': True, 'message': 'Credentials valid'}), 200
        else:
            print(f"[Login] Invalid credentials for email: {email}")
            return jsonify({'success': False, 'message': 'Invalid email or password'}), 401
            
    except Exception as e:
        print(f"[Login] Error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': 'Server error during login'}), 500

# ==================== FLIGHTS API ====================
@app.route('/api/flights', methods=['GET'])
def get_flights():
    """Get all flights with optional filtering"""
    try:
        origin = request.args.get('origin')
        destination = request.args.get('destination')
        
        flights = get_all_flights(origin, destination)
        
        for flight in flights:
            # Safe JSON parsing
            if flight.get('features') and isinstance(flight['features'], str):
                try:
                    flight['features'] = json.loads(flight['features'])
                except:
                    flight['features'] = []
            
            # Safe price conversion
            try:
                flight['price'] = float(flight['price']) if flight.get('price') is not None else 0.0
            except:
                flight['price'] = 0.0
        
        return jsonify({'status': 'success', 'data': flights}), 200
    except Exception as e:
        print(f"API Error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/flights/<int:flight_id>', methods=['GET'])
def get_flight(flight_id):
    """Get flight by ID"""
    try:
        flight = get_flight_by_id(flight_id)
        
        if not flight:
            return jsonify({'status': 'error', 'message': 'Flight not found'}), 404
        
        if flight.get('features'):
            flight['features'] = json.loads(flight['features'])
        flight['price'] = float(flight['price'])
        
        return jsonify({'status': 'success', 'data': flight}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ==================== HOTELS API (UPDATED) ====================
@app.route('/api/hotels', methods=['GET'])
def get_hotels():
    """Get all hotels with optional filtering"""
    try:
        city = request.args.get('city')
        show_all = request.args.get('show_all') == 'true'
        
        hotels = get_all_hotels(city, show_all)
        
        for hotel in hotels:
            if hotel.get('amenities'):
                hotel['amenities'] = json.loads(hotel['amenities'])
            if hotel.get('room_types'):
                hotel['room_types'] = json.loads(hotel['room_types'])
            hotel['price_per_night'] = float(hotel['price_per_night'])
            hotel['rating'] = float(hotel['rating']) if hotel['rating'] else None
        
        return jsonify({'status': 'success', 'data': hotels}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/hotels/<int:hotel_id>', methods=['GET'])
def get_hotel(hotel_id):
    """Get hotel by ID"""
    try:
        hotel = get_hotel_by_id(hotel_id)
        
        if not hotel:
            return jsonify({'status': 'error', 'message': 'Hotel not found'}), 404
        
        if hotel.get('amenities'):
            hotel['amenities'] = json.loads(hotel['amenities'])
        if hotel.get('room_types'):
            hotel['room_types'] = json.loads(hotel['room_types'])
        hotel['price_per_night'] = float(hotel['price_per_night'])
        hotel['rating'] = float(hotel['rating']) if hotel['rating'] else None
        
        return jsonify({'status': 'success', 'data': hotel}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ==================== PACKAGES API ====================
@app.route('/api/packages', methods=['GET'])
def get_packages():
    """Get all packages with optional filtering"""
    try:
        category = request.args.get('category')
        destination = request.args.get('destination')
        
        packages = get_all_packages(category, destination)
        
        for package in packages:
            # Safe JSON parsing for features
            if package.get('features'):
                if isinstance(package['features'], str):
                    try:
                        package['features'] = json.loads(package['features'])
                    except (json.JSONDecodeError, TypeError):
                        package['features'] = []
            
            # Safe price conversion
            try:
                if package.get('price') is not None:
                    package['price'] = float(package['price'])
                else:
                    package['price'] = 0.0
            except (ValueError, TypeError):
                package['price'] = 0.0
        
        return jsonify({'status': 'success', 'data': packages}), 200
    except Exception as e:
        print(f"API Error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500
    

@app.route('/api/packages/<int:package_id>', methods=['GET'])
def get_package(package_id):
    """Get package by ID"""
    try:
        package = get_package_by_id(package_id)
        
        if not package:
            return jsonify({'status': 'error', 'message': 'Package not found'}), 404
        
        if package.get('features'):
            package['features'] = json.loads(package['features'])
        package['price'] = float(package['price'])
        
        return jsonify({'status': 'success', 'data': package}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ==================== TRAINS API ====================
@app.route('/api/trains', methods=['GET'])
def get_trains():
    """Get all trains with optional filtering"""
    try:
        origin = request.args.get('origin')
        destination = request.args.get('destination')
        
        trains = get_all_trains(origin, destination)
        
        for train in trains:
            if train.get('features'):
                train['features'] = json.loads(train['features'])
            train['price'] = float(train['price'])
        
        return jsonify({'status': 'success', 'data': trains}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/trains/<int:train_id>', methods=['GET'])
def get_train(train_id):
    """Get train by ID"""
    try:
        train = get_train_by_id(train_id)
        
        if not train:
            return jsonify({'status': 'error', 'message': 'Train not found'}), 404
        
        if train.get('features'):
            train['features'] = json.loads(train['features'])
        train['price'] = float(train['price'])
        
        return jsonify({'status': 'success', 'data': train}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ==================== USERS API ====================
@app.route('/api/users', methods=['POST'])
def create_user_route():
    """Create a new user"""
    try:
        data = request.get_json()
        if not all(k in data for k in ('name', 'email', 'phone', 'password_hash')):
            return jsonify({'status': 'error', 'message': 'Missing required fields'}), 400
        
        result = create_user(data['name'], data['email'], data['phone'], data['password_hash'])
        
        if result['success']:
            return jsonify({'status': 'success', 'message': 'User created', 'user_id': result['user_id']}), 201
        else:
            return jsonify({'status': 'error', 'message': result.get('message', 'Failed to create user')}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/users/<int:user_id>', methods=['GET'])
def get_user_route(user_id):
    """Get user by ID"""
    try:
        user = get_user_by_id(user_id)
        if not user:
            return jsonify({'status': 'error', 'message': 'User not found'}), 404
        return jsonify({'status': 'success', 'data': user}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/users/by-email/<email>', methods=['GET'])
def get_user_by_email_route(email):
    """Get user profile by email address"""
    try:
        user = get_user_by_email(email)
        if not user:
            return jsonify({'status': 'error', 'message': 'User not found'}), 404
        # Remove password_hash from response
        user_data = {k: v for k, v in user.items() if k != 'password_hash'}
        return jsonify({'status': 'success', 'data': user_data}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/users/update-profile', methods=['PUT'])
def update_user_profile_route():
    """Update user profile (name, email, phone)"""
    try:
        data = request.get_json()
        current_email = data.get('current_email')
        new_name = data.get('name', '').strip()
        new_email = data.get('email', '').strip()
        new_phone = data.get('phone', '').strip()
        
        if not current_email:
            return jsonify({'status': 'error', 'message': 'Current email is required'}), 400
        
        if not new_name or not new_email:
            return jsonify({'status': 'error', 'message': 'Name and email are required'}), 400
        
        result = update_user_profile(current_email, new_name, new_email, new_phone)
        
        if result['success']:
            return jsonify({
                'status': 'success', 
                'message': 'Profile updated successfully',
                'data': result['data']
            }), 200
        else:
            status_code = 404 if result.get('message') == 'User not found' else 400
            return jsonify({'status': 'error', 'message': result.get('message')}), status_code
            
    except Exception as e:
        print(f"Error updating profile: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/users/change-password', methods=['PUT'])
def change_user_password_route():
    """Change user password"""
    try:
        data = request.get_json()
        email = data.get('email')
        current_password = data.get('current_password', '').strip()
        new_password = data.get('new_password', '').strip()
        
        if not email or not current_password or not new_password:
            return jsonify({'status': 'error', 'message': 'Email, current password, and new password are required'}), 400
        
        if len(new_password) < 6:
            return jsonify({'status': 'error', 'message': 'New password must be at least 6 characters long'}), 400
        
        # Verify current password
        user = get_user_by_email(email)
        
        if not user:
            return jsonify({'status': 'error', 'message': 'User not found'}), 404
        
        # Check if current password matches
        if not check_password_hash(user['password_hash'], current_password):
            return jsonify({'status': 'error', 'message': 'Current password is incorrect'}), 401
        
        # Hash the new password
        hashed_new_password = generate_password_hash(new_password, method='pbkdf2:sha256', salt_length=16)
        
        # Update password
        result = change_user_password(email, hashed_new_password)
        
        if result['success']:
            return jsonify({
                'status': 'success', 
                'message': 'Password changed successfully'
            }), 200
        else:
            return jsonify({'status': 'error', 'message': 'Failed to update password'}), 500
            
    except Exception as e:
        print(f"Error changing password: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ==================== BOOKINGS API ====================
@app.route('/api/bookings', methods=['POST'])
def create_booking_route():
    """Create a basic booking"""
    try:
        data = request.get_json()
        required = ['user_id', 'booking_type', 'travel_date', 'num_travelers', 'total_price']
        if not all(field in data for field in required):
            return jsonify({'status': 'error', 'message': 'Missing required fields'}), 400
        
        result = create_booking(
            user_id=data.get('user_id'),
            booking_type=data.get('booking_type'),
            travel_date=data.get('travel_date'),
            return_date=data.get('return_date'),
            num_travelers=data.get('num_travelers', 1),
            total_price=data.get('total_price'),
            status=data.get('status', 'pending'),
            payment_status=data.get('payment_status', 'pending')
        )
        
        if result['success']:
            return jsonify({'status': 'success', 'message': 'Booking created', 'booking_id': result['booking_id']}), 201
        else:
            return jsonify({'status': 'error', 'message': result.get('message', 'Failed to create booking')}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/bookings/user/<int:user_id>', methods=['GET'])
def get_user_bookings_route(user_id):
    """Get all bookings for a user"""
    try:
        print(f"Fetching bookings for user_id: {user_id}")
        bookings = get_user_bookings(user_id)
        print(f"Found {len(bookings)} bookings for user_id {user_id}")
        return jsonify({'status': 'success', 'data': bookings}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ==================== ADMIN MANAGEMENT ROUTES ====================
@app.route('/api/admin/bookings', methods=['GET'])
def get_all_bookings_route():
    """Get all bookings for admin"""
    try:
        bookings = get_all_bookings()
        return jsonify({'status': 'success', 'data': bookings}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/admin/bookings/<int:booking_id>', methods=['PUT'])
def update_booking_status_route(booking_id):
    """Update booking status and payment status"""
    try:
        data = request.json
        
        status = data.get('status')
        payment_status = data.get('payment_status')
        
        if not status and not payment_status:
            return jsonify({'status': 'error', 'message': 'No fields to update'}), 400
        
        success = update_booking_status(booking_id, status, payment_status)
        
        if success:
            return jsonify({'status': 'success', 'message': 'Booking updated'}), 200
        else:
            return jsonify({'status': 'error', 'message': 'Failed to update booking'}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ==================== USER BOOKING ROUTES ====================
@app.route('/api/create_booking_with_details', methods=['POST'])
def create_booking_with_details():
    """Create booking with complete details from payment page"""
    try:
        data = request.get_json()
        
        # Required fields
        required = ['booking_ref', 'type', 'name', 'price', 'travellers']
        if not all(field in data for field in required):
            return jsonify({'status': 'error', 'message': 'Missing required fields'}), 400
        
        # Get user_id (use provided value, or default to 1 for guest bookings)
        user_id = data.get('user_id')
        if user_id is None:
            user_id = DEFAULT_USER_ID
        
        print(f"Creating booking with user_id: {user_id}, booking_ref: {data.get('booking_ref')}")
        
        # Parse dates using utility function
        date_str = data.get('date')
        travel_date, return_date = parse_date_range(date_str)
        
        print(f"Final travel_date: {travel_date}, return_date: {return_date}")
        
        result = create_booking(
            user_id=user_id,
            booking_type=data.get('type'),
            travel_date=travel_date,
            return_date=return_date,
            num_travelers=data.get('travellers', 1),
            total_price=data.get('price'),
            status='confirmed',
            payment_status='completed',
            booking_ref=data.get('booking_ref')
        )
        
        if result['success']:
            print(f"✓ Booking created successfully with ID: {result['booking_id']}")
            return jsonify({
                'status': 'success', 
                'message': 'Booking created successfully', 
                'booking_id': result['booking_id'],
                'booking_ref': data.get('booking_ref')
            }), 201
        else:
            return jsonify({'status': 'error', 'message': result.get('message', 'Failed to create booking')}), 500
        
    except Exception as e:
        print(f"!!! Error creating booking: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/cancel_booking', methods=['POST'])
def cancel_booking_route():
    """Cancel a booking by booking reference"""
    try:
        data = request.get_json()
        booking_ref = data.get('bookingRef')
        
        if not booking_ref:
            return jsonify({'status': 'error', 'message': 'Booking reference required'}), 400
        
        success = cancel_booking(booking_ref)
        
        if success:
            return jsonify({'status': 'success', 'message': 'Booking cancelled successfully'}), 200
        else:
            return jsonify({'status': 'error', 'message': 'Booking not found'}), 404
            
    except Exception as e:
        print(f"Error cancelling booking: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/admin/users', methods=['GET'])
def get_all_users_route():
    """Get all users for admin"""
    try:
        users = get_all_users()
        return jsonify({'status': 'success', 'data': users}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/admin/users/<int:user_id>', methods=['PUT'])
def update_user_status_route(user_id):
    """Update user active status"""
    try:
        data = request.json
        is_active = data.get('is_active', 1)
        
        success = update_user_status(user_id, is_active)
        
        if success:
            return jsonify({'status': 'success', 'message': 'User status updated'}), 200
        else:
            return jsonify({'status': 'error', 'message': 'Failed to update user status'}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/admin/stats', methods=['GET'])
def get_admin_stats_route():
    """Get dashboard statistics"""
    try:
        stats = get_admin_stats()
        return jsonify({'status': 'success', 'data': stats}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/admin/analytics', methods=['GET'])
def get_analytics():
    """Get comprehensive analytics data with date filtering"""
    try:
        # Get date range from query params (default: last 30 days)
        start_date = request.args.get('start_date', '2026-01-01')
        end_date = request.args.get('end_date', '2026-12-31')
        
        analytics = get_analytics_data(start_date, end_date)
        
        return jsonify({'status': 'success', 'data': analytics}), 200
    except Exception as e:
        print(f"Analytics Error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/admin/flights', methods=['POST'])
def add_flight_route():
    """Add new flight"""
    try:
        data = request.json
        result = add_flight(data)
        
        if result['success']:
            return jsonify({'status': 'success', 'message': 'Flight added', 'id': result['id']}), 201
        else:
            return jsonify({'status': 'error', 'message': result.get('message', 'Failed to add flight')}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/admin/flights/<int:flight_id>', methods=['PUT'])
def update_flight_route(flight_id):
    """Update flight"""
    try:
        data = request.json
        print(f"Updating flight {flight_id} with data: {data}")
        
        result = update_flight(flight_id, data)
        
        if result['success']:
            print(f"Flight {flight_id} updated successfully")
            return jsonify({'status': 'success', 'message': 'Flight updated'}), 200
        else:
            print(f"Failed to update flight {flight_id}: {result.get('message')}")
            status_code = 404 if result.get('message') == 'Flight not found' else 500
            return jsonify({'status': 'error', 'message': result.get('message')}), status_code
    except Exception as e:
        print(f"Error updating flight: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/admin/flights/<int:flight_id>', methods=['DELETE'])
def delete_flight_route(flight_id):
    """Delete flight (soft delete)"""
    try:
        success = delete_flight(flight_id)
        
        if success:
            return jsonify({'status': 'success', 'message': 'Flight deleted'}), 200
        else:
            return jsonify({'status': 'error', 'message': 'Failed to delete flight'}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ==================== ADMIN HOTELS MANAGEMENT ====================
@app.route('/api/admin/hotels/<int:hotel_id>', methods=['PUT'])
def update_hotel_route(hotel_id):
    """Update hotel"""
    try:
        data = request.json
        success = update_hotel(hotel_id, data)
        
        if success:
            return jsonify({'status': 'success', 'message': 'Hotel updated'}), 200
        else:
            return jsonify({'status': 'error', 'message': 'Failed to update hotel'}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/admin/hotels/<int:hotel_id>', methods=['DELETE'])
def delete_hotel_route(hotel_id):
    """Delete hotel (soft delete)"""
    try:
        success = delete_hotel(hotel_id)
        
        if success:
            return jsonify({'status': 'success', 'message': 'Hotel deleted'}), 200
        else:
            return jsonify({'status': 'error', 'message': 'Failed to delete hotel'}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ==================== ADMIN PACKAGES MANAGEMENT ====================
@app.route('/api/admin/packages/<int:package_id>', methods=['PUT'])
def update_package_route(package_id):
    """Update package"""
    try:
        data = request.json
        success = update_package(package_id, data)
        
        if success:
            return jsonify({'status': 'success', 'message': 'Package updated'}), 200
        else:
            return jsonify({'status': 'error', 'message': 'Failed to update package'}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/admin/packages/<int:package_id>', methods=['DELETE'])
def delete_package_route(package_id):
    """Delete package (soft delete)"""
    try:
        success = delete_package(package_id)
        
        if success:
            return jsonify({'status': 'success', 'message': 'Package deleted'}), 200
        else:
            return jsonify({'status': 'error', 'message': 'Failed to delete package'}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ==================== ADMIN TRAINS MANAGEMENT ====================
@app.route('/api/admin/trains/<int:train_id>', methods=['PUT'])
def update_train_route(train_id):
    """Update train"""
    try:
        data = request.json
        print(f"Updating train {train_id} with data: {data}")
        
        result = update_train(train_id, data)
        
        if result['success']:
            print(f"Train {train_id} updated successfully")
            return jsonify({'status': 'success', 'message': 'Train updated'}), 200
        else:
            print(f"Failed to update train {train_id}: {result.get('message')}")
            status_code = 404 if result.get('message') == 'Train not found' else 500
            return jsonify({'status': 'error', 'message': result.get('message')}), status_code
    except Exception as e:
        print(f"Error updating train: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/admin/trains/<int:train_id>', methods=['DELETE'])
def delete_train_route(train_id):
    """Delete train (soft delete)"""
    try:
        success = delete_train(train_id)
        
        if success:
            return jsonify({'status': 'success', 'message': 'Train deleted'}), 200
        else:
            return jsonify({'status': 'error', 'message': 'Failed to delete train'}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ==================== ADMIN BOOKINGS MANAGEMENT ====================
@app.route('/api/admin/bookings/<int:booking_id>', methods=['DELETE'])
def delete_booking_route(booking_id):
    """Delete booking (hard delete)"""
    try:
        success = delete_booking(booking_id)
        
        if success:
            return jsonify({'status': 'success', 'message': 'Booking deleted'}), 200
        else:
            return jsonify({'status': 'error', 'message': 'Failed to delete booking'}), 500
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ==================== SAVED ITEMS ROUTES ====================
@app.route('/api/saved-items', methods=['POST'])
def add_saved_item_route():
    """Add an item to user's saved list"""
    try:
        data = request.json
        user_email = data.get('user_email')
        item_type = data.get('item_type')
        item_id = data.get('item_id')
        
        print(f"[Saved Items] Add request - Email: {user_email}, Type: {item_type}, ID: {item_id}")
        
        if not all([user_email, item_type, item_id]):
            return jsonify({'success': False, 'message': 'Missing required fields'}), 400
        
        result = add_saved_item(user_email, item_type, item_id)
        
        if result['success']:
            print(f"[Saved Items] Successfully saved to database")
            return jsonify({'success': True, 'message': 'Item saved successfully'}), 200
        else:
            status_code = 404 if result.get('message') == 'User not found' else 400
            print(f"[Saved Items] Failed: {result.get('message')}")
            return jsonify({'success': False, 'message': result.get('message')}), status_code
        
    except Exception as e:
        print(f"Error saving item: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/saved-items/<path:user_email>', methods=['GET'])
def get_saved_items_route(user_email):
    """Get all saved items for a user with full details"""
    try:
        from urllib.parse import unquote
        user_email = unquote(user_email)  # Decode URL-encoded email
        print(f"[Saved Items] Fetch request for user: {user_email}")
        
        saved_items = get_saved_items(user_email)
        
        print(f"[Saved Items] Returning {len(saved_items)} items with full details")
        return jsonify({'success': True, 'savedItems': saved_items}), 200
        
    except Exception as e:
        print(f"Error fetching saved items: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/saved-items', methods=['DELETE'])
def delete_saved_item_route():
    """Delete a saved item"""
    try:
        data = request.json
        user_email = data.get('user_email')
        item_type = data.get('item_type')
        item_id = data.get('item_id')
        
        print(f"[Saved Items] Delete request - Email: {user_email}, Type: {item_type}, ID: {item_id}")
        
        if not all([user_email, item_type, item_id]):
            return jsonify({'success': False, 'message': 'Missing required fields'}), 400
        
        result = delete_saved_item(user_email, item_type, item_id)
        
        if result['success']:
            print(f"[Saved Items] Successfully deleted from database")
            return jsonify({'success': True, 'message': 'Item removed from saved list'}), 200
        else:
            status_code = 404 if result.get('message') == 'User not found' else 500
            print(f"[Saved Items] Failed: {result.get('message')}")
            return jsonify({'success': False, 'message': result.get('message')}), status_code
        
    except Exception as e:
        print(f"Error deleting saved item: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


# ==================== CONTACT MESSAGES ROUTES ====================
@app.route('/api/contact-messages', methods=['POST'])
def submit_contact_message():
    """Submit a new contact message"""
    try:
        data = request.json
        name = data.get('name')
        email = data.get('email')
        topic = data.get('topic')
        message = data.get('message')
        
        print(f"[Contact] New message from: {name} ({email}) - Topic: {topic}")
        
        if not all([name, email, topic, message]):
            return jsonify({'success': False, 'message': 'All fields are required'}), 400
        
        result = create_contact_message(name, email, topic, message)
        
        if result['success']:
            print(f"[Contact] Message saved successfully - ID: {result.get('message_id')}")
            return jsonify(result), 201
        else:
            return jsonify(result), 500
        
    except Exception as e:
        print(f"Error submitting contact message: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/contact-messages', methods=['GET'])
def get_contact_messages():
    """Get all contact messages (admin only)"""
    try:
        messages = get_all_contact_messages()
        return jsonify({'success': True, 'messages': messages}), 200
    except Exception as e:
        print(f"Error fetching contact messages: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/contact-messages/<int:message_id>/status', methods=['PUT'])
def update_message_status(message_id):
    """Update contact message status (admin only)"""
    try:
        data = request.json
        status = data.get('status')
        
        if not status or status not in ['new', 'read', 'replied', 'archived']:
            return jsonify({'success': False, 'message': 'Invalid status'}), 400
        
        result = update_contact_message_status(message_id, status)
        return jsonify(result), 200 if result['success'] else 500
        
    except Exception as e:
        print(f"Error updating message status: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/contact-messages/<int:message_id>', methods=['DELETE'])
def delete_contact_message_route(message_id):
    """Delete a contact message (admin only)"""
    try:
        result = delete_contact_message(message_id)
        return jsonify(result), 200 if result['success'] else 500
    except Exception as e:
        print(f"Error deleting contact message: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

# ==================== ERROR HANDLERS ====================
@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({'status': 'error', 'message': 'Endpoint not found'}), 404


# ==================== MAIN ENTRY POINT ====================
if __name__ == '__main__':
    app.run(debug=FLASK_DEBUG, host=FLASK_HOST, port=FLASK_PORT, use_reloader=False)

