"""
Configuration file for TripBuddy application
Contains all settings, constants, and configuration variables
"""

# ==================== DATABASE CONFIGURATION ====================
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'tripbuddy_db'
}

# ==================== SMTP CONFIGURATION ====================
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USER = "tripbuddy1234@gmail.com"
SMTP_PASS = "zqapshgqzxstudoa"

# ==================== OTP CONFIGURATION ====================
OTP_LENGTH = 6
OTP_EXPIRY_TIME = 120  # 2 minutes in seconds
OTP_RESEND_COOLDOWN = 60  # 1 minute in seconds

# In-memory storage for OTP (consider Redis for production)
otp_store = {}
otp_resend_time = {}

# ==================== FLASK CONFIGURATION ====================
FLASK_HOST = '0.0.0.0'
FLASK_PORT = 5000
FLASK_DEBUG = True

# ==================== CORS CONFIGURATION ====================
CORS_ORIGINS = [
    "http://127.0.0.1:5500",
    "http://localhost:5500",
    "http://127.0.0.1:5501"
]

CORS_METHODS = ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
CORS_HEADERS = ["Content-Type", "Authorization"]
CORS_SUPPORTS_CREDENTIALS = True

# ==================== BOOKING CONFIGURATION ====================
DEFAULT_USER_ID = 1  # Default guest user ID for bookings
