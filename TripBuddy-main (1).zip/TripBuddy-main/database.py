"""
Database layer for TripBuddy application
Contains all database connection and data access functions
"""

import mysql.connector
from mysql.connector import Error
from werkzeug.security import generate_password_hash
from datetime import datetime
from config import db_config


# ==================== DATABASE CONNECTION ====================
def get_db_connection():
    """Get MySQL database connection"""
    try:
        conn = mysql.connector.connect(**db_config)
        return conn
    except Error as e:
        print(f"Database Connection Error: {e}")
        return None


# ==================== ADMIN DATABASE FUNCTIONS ====================
def get_admin_by_email(email):
    """Get admin user by email"""
    try:
        conn = get_db_connection()
        if not conn:
            return None
        cursor = conn.cursor(dictionary=True)
        query = "SELECT id, username, email, password_hash FROM admin WHERE email = %s AND is_active = 1"
        cursor.execute(query, (email,))
        admin = cursor.fetchone()
        cursor.close()
        conn.close()
        return admin
    except Exception as e:
        print(f"Error fetching admin: {e}")
        return None


def update_admin_credentials():
    """
    Update admin credentials in database
    """
    try:
        conn = get_db_connection()
        if not conn:
            print("Failed to connect to database")
            return False
            
        cursor = conn.cursor()
        
        # Update Admin 2
        update_admin2 = """
        UPDATE `admin` 
        SET `email` = 'harshil8744@gmail.com',
            `password_hash` = 'pbkdf2:sha256:1000000$iUwaFT9Yo8RgbxHy$a716e72a51c301b8314f95c7f25ebfa4462f0debdf37c4c11973d88a43b2a770'
        WHERE `id` = 2;
        """
        
        # Update Admin 3
        update_admin3 = """
        UPDATE `admin` 
        SET `email` = 'jhanvishah1316@gmail.com',
            `password_hash` = 'pbkdf2:sha256:1000000$BSYShsOCqhkl9ZOK$954dd28cd1e3e07e1f36348aa30dcb833e315eadbbcc1a16ce5b53f89f34fd2e'
        WHERE `id` = 3;
        """
        
        cursor.execute(update_admin2)
        cursor.execute(update_admin3)
        
        conn.commit()
        
        print("✓ Admin 2 updated successfully!")
        print("  Email: harshil8744@gmail.com")
        print("  Password: harshil8744")
        print()
        print("✓ Admin 3 updated successfully!")
        print("  Email: jhanvishah1316@gmail.com")
        print("  Password: jhanvi1316")
        
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"Error updating admin credentials: {e}")
        return False


# ==================== USER DATABASE FUNCTIONS ====================
def create_user(name, email, phone, password):
    """Create a new user"""
    try:
        conn = get_db_connection()
        if not conn:
            return {'success': False, 'message': 'Database connection failed'}
        
        cursor = conn.cursor()
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)
        
        insert_query = "INSERT INTO users (name, email, phone, password_hash) VALUES (%s, %s, %s, %s)"
        cursor.execute(insert_query, (name, email, phone, hashed_password))
        conn.commit()
        user_id = cursor.lastrowid
        
        cursor.close()
        conn.close()
        return {'success': True, 'user_id': user_id}
    except Exception as e:
        return {'success': False, 'message': str(e)}


def get_user_by_id(user_id):
    """Get user by ID"""
    try:
        conn = get_db_connection()
        if not conn:
            return None
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id, name, email, phone, created_at, is_active FROM users WHERE id = %s", (user_id,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        return user
    except Exception as e:
        print(f"Error fetching user: {e}")
        return None


def get_user_by_email(email):
    """Get user by email"""
    try:
        conn = get_db_connection()
        if not conn:
            return None
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        return user
    except Exception as e:
        print(f"Error fetching user by email: {e}")
        return None


def update_user_profile(current_email, new_name, new_email, new_phone):
    """Update user profile"""
    try:
        conn = get_db_connection()
        if not conn:
            return {'success': False, 'message': 'Database connection failed'}
        
        cursor = conn.cursor()
        
        # Check if email is being changed and if new email already exists
        if new_email != current_email:
            cursor.execute("SELECT id FROM users WHERE email = %s", (new_email,))
            existing_user = cursor.fetchone()
            if existing_user:
                cursor.close()
                conn.close()
                return {'success': False, 'message': 'This email is already registered'}
        
        # Update user profile
        update_query = """UPDATE users 
                         SET name = %s, email = %s, phone = %s 
                         WHERE email = %s"""
        
        cursor.execute(update_query, (new_name, new_email, new_phone, current_email))
        conn.commit()
        rows_affected = cursor.rowcount
        
        cursor.close()
        conn.close()
        
        if rows_affected > 0:
            return {
                'success': True,
                'data': {
                    'name': new_name,
                    'email': new_email,
                    'phone': new_phone
                }
            }
        else:
            return {'success': False, 'message': 'User not found'}
    except Exception as e:
        return {'success': False, 'message': str(e)}


def change_user_password(email, new_password_hash):
    """Change user password"""
    try:
        conn = get_db_connection()
        if not conn:
            return {'success': False, 'message': 'Database connection failed'}
        
        cursor = conn.cursor()
        update_query = "UPDATE users SET password_hash = %s WHERE email = %s"
        cursor.execute(update_query, (new_password_hash, email))
        conn.commit()
        rows_affected = cursor.rowcount
        
        cursor.close()
        conn.close()
        
        return {'success': rows_affected > 0}
    except Exception as e:
        return {'success': False, 'message': str(e)}


def get_all_users():
    """Get all users"""
    try:
        conn = get_db_connection()
        if not conn:
            return []
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id, name, email, phone, created_at, is_active FROM users ORDER BY created_at DESC")
        users = cursor.fetchall()
        cursor.close()
        conn.close()
        return users
    except Exception as e:
        print(f"Error fetching users: {e}")
        return []


def update_user_status(user_id, is_active):
    """Update user active status"""
    try:
        conn = get_db_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET is_active = %s WHERE id = %s", (is_active, user_id))
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Error updating user status: {e}")
        return False


# ==================== BOOKING DATABASE FUNCTIONS ====================
def create_booking(user_id, booking_type, travel_date, return_date, num_travelers, 
                   total_price, status='pending', payment_status='pending', booking_ref=None):
    """Create a new booking"""
    try:
        conn = get_db_connection()
        if not conn:
            return {'success': False, 'message': 'Database connection failed'}
        
        cursor = conn.cursor()
        insert_query = """INSERT INTO bookings 
                        (user_id, booking_type, travel_date, return_date, num_travelers, 
                         total_price, status, payment_status, booking_reference)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"""
        
        cursor.execute(insert_query, (user_id, booking_type, travel_date, return_date, 
                                     num_travelers, total_price, status, payment_status, booking_ref))
        conn.commit()
        booking_id = cursor.lastrowid
        
        cursor.close()
        conn.close()
        return {'success': True, 'booking_id': booking_id}
    except Exception as e:
        return {'success': False, 'message': str(e)}


def get_user_bookings(user_id):
    """Get all bookings for a user"""
    try:
        conn = get_db_connection()
        if not conn:
            return []
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM bookings WHERE user_id = %s ORDER BY created_at DESC", (user_id,))
        bookings = cursor.fetchall()
        for booking in bookings:
            booking['total_price'] = float(booking['total_price'])
        cursor.close()
        conn.close()
        return bookings
    except Exception as e:
        print(f"Error fetching user bookings: {e}")
        return []


def get_all_bookings():
    """Get all bookings for admin"""
    try:
        conn = get_db_connection()
        if not conn:
            return []
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT b.*, u.name as user_name, u.email as user_email 
            FROM bookings b 
            LEFT JOIN users u ON b.user_id = u.id 
            ORDER BY b.created_at DESC
        """)
        bookings = cursor.fetchall()
        for booking in bookings:
            booking['total_price'] = float(booking['total_price'])
        cursor.close()
        conn.close()
        return bookings
    except Exception as e:
        print(f"Error fetching all bookings: {e}")
        return []


def update_booking_status(booking_id, status=None, payment_status=None):
    """Update booking status and/or payment status"""
    try:
        conn = get_db_connection()
        if not conn:
            return False
        
        cursor = conn.cursor()
        update_fields = []
        params = []
        
        if status is not None:
            update_fields.append("status = %s")
            params.append(status)
        if payment_status is not None:
            update_fields.append("payment_status = %s")
            params.append(payment_status)
        
        if not update_fields:
            return False
        
        params.append(booking_id)
        query = f"UPDATE bookings SET {', '.join(update_fields)} WHERE id = %s"
        cursor.execute(query, params)
        conn.commit()
        
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Error updating booking status: {e}")
        return False


def cancel_booking(booking_ref):
    """Cancel a booking by booking reference"""
    try:
        conn = get_db_connection()
        if not conn:
            return False
        
        cursor = conn.cursor()
        update_query = """UPDATE bookings 
                         SET status = 'cancelled', payment_status = 'refunded' 
                         WHERE booking_reference = %s"""
        cursor.execute(update_query, (booking_ref,))
        conn.commit()
        rows_affected = cursor.rowcount
        
        cursor.close()
        conn.close()
        return rows_affected > 0
    except Exception as e:
        print(f"Error cancelling booking: {e}")
        return False


def delete_booking(booking_id):
    """Delete booking (hard delete)"""
    try:
        conn = get_db_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        cursor.execute("DELETE FROM bookings WHERE id = %s", (booking_id,))
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Error deleting booking: {e}")
        return False


# ==================== FLIGHTS DATABASE FUNCTIONS ====================
def get_all_flights(origin=None, destination=None):
    """Get all flights with optional filtering"""
    try:
        conn = get_db_connection()
        if not conn:
            return []
        cursor = conn.cursor(dictionary=True)
        
        query = "SELECT * FROM flights WHERE is_active = 1"
        params = []
        
        if origin:
            query += " AND origin LIKE %s"
            params.append(f"%{origin}%")
        if destination:
            query += " AND destination LIKE %s"
            params.append(f"%{destination}%")
        
        cursor.execute(query, params)
        flights = cursor.fetchall()
        
        cursor.close()
        conn.close()
        return flights
    except Exception as e:
        print(f"Error fetching flights: {e}")
        return []


def get_flight_by_id(flight_id):
    """Get flight by ID"""
    try:
        conn = get_db_connection()
        if not conn:
            return None
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM flights WHERE id = %s", (flight_id,))
        flight = cursor.fetchone()
        cursor.close()
        conn.close()
        return flight
    except Exception as e:
        print(f"Error fetching flight: {e}")
        return None


def add_flight(data):
    """Add new flight"""
    try:
        conn = get_db_connection()
        if not conn:
            return {'success': False, 'message': 'Database connection failed'}
        
        cursor = conn.cursor()
        query = """INSERT INTO flights (airline, airline_name, flight_number, origin, destination, 
                   origin_code, destination_code, departure_time, arrival_time, duration, price, 
                   category, features, available_seats) 
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
        
        import json
        cursor.execute(query, (
            data.get('airline'), data.get('airline_name'), data.get('flight_number'),
            data.get('origin'), data.get('destination'), data.get('origin_code'),
            data.get('destination_code'), data.get('departure_time'), data.get('arrival_time'),
            data.get('duration'), data.get('price'), data.get('category'),
            json.dumps(data.get('features', [])), data.get('available_seats', 100)
        ))
        
        conn.commit()
        flight_id = cursor.lastrowid
        
        cursor.close()
        conn.close()
        return {'success': True, 'id': flight_id}
    except Exception as e:
        return {'success': False, 'message': str(e)}


def update_flight(flight_id, data):
    """Update flight"""
    try:
        conn = get_db_connection()
        if not conn:
            return {'success': False, 'message': 'Database connection failed'}
        
        cursor = conn.cursor(dictionary=True)
        
        # Get current flight data
        cursor.execute("SELECT * FROM flights WHERE id = %s", (flight_id,))
        current = cursor.fetchone()
        
        if not current:
            cursor.close()
            conn.close()
            return {'success': False, 'message': 'Flight not found'}
        
        # Merge current data with updates
        query = """UPDATE flights SET airline = %s, airline_name = %s, flight_number = %s,
                   origin = %s, destination = %s, departure_time = %s, arrival_time = %s,
                   duration = %s, price = %s, available_seats = %s, is_active = %s
                   WHERE id = %s"""
        
        cursor.execute(query, (
            data.get('airline', current['airline']),
            data.get('airline_name', current['airline_name']),
            data.get('flight_number', current['flight_number']),
            data.get('origin', current['origin']),
            data.get('destination', current['destination']),
            data.get('departure_time', current['departure_time']),
            data.get('arrival_time', current['arrival_time']),
            data.get('duration', current['duration']),
            data.get('price', current['price']),
            data.get('available_seats', current['available_seats']),
            data.get('is_active', current['is_active']),
            flight_id
        ))
        
        conn.commit()
        cursor.close()
        conn.close()
        return {'success': True}
    except Exception as e:
        return {'success': False, 'message': str(e)}


def delete_flight(flight_id):
    """Delete flight (soft delete)"""
    try:
        conn = get_db_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        cursor.execute("UPDATE flights SET is_active = 0 WHERE id = %s", (flight_id,))
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Error deleting flight: {e}")
        return False


# ==================== HOTELS DATABASE FUNCTIONS ====================
def get_all_hotels(city=None, show_all=False):
    """Get all hotels with optional filtering"""
    try:
        conn = get_db_connection()
        if not conn:
            return []
        cursor = conn.cursor(dictionary=True)
        
        query = "SELECT * FROM hotels WHERE is_active = 1"
        params = []
        
        if city:
            query += " AND city LIKE %s"
            params.append(f"%{city}%")
        
        if not show_all:
            query += " LIMIT 8"
        
        cursor.execute(query, params)
        hotels = cursor.fetchall()
        
        cursor.close()
        conn.close()
        return hotels
    except Exception as e:
        print(f"Error fetching hotels: {e}")
        return []


def get_hotel_by_id(hotel_id):
    """Get hotel by ID"""
    try:
        conn = get_db_connection()
        if not conn:
            return None
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM hotels WHERE id = %s", (hotel_id,))
        hotel = cursor.fetchone()
        cursor.close()
        conn.close()
        return hotel
    except Exception as e:
        print(f"Error fetching hotel: {e}")
        return None


def update_hotel(hotel_id, data):
    """Update hotel"""
    try:
        conn = get_db_connection()
        if not conn:
            return False
        
        cursor = conn.cursor()
        query = """UPDATE hotels SET name = %s, city = %s, address = %s, rating = %s,
                   price_per_night = %s, is_active = %s WHERE id = %s"""
        
        cursor.execute(query, (
            data.get('name'), data.get('city'), data.get('address'),
            data.get('rating'), data.get('price_per_night'),
            data.get('is_active', 1), hotel_id
        ))
        
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Error updating hotel: {e}")
        return False


def delete_hotel(hotel_id):
    """Delete hotel (soft delete)"""
    try:
        conn = get_db_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        cursor.execute("UPDATE hotels SET is_active = 0 WHERE id = %s", (hotel_id,))
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Error deleting hotel: {e}")
        return False


# ==================== PACKAGES DATABASE FUNCTIONS ====================
def get_all_packages(category=None, destination=None):
    """Get all packages with optional filtering"""
    try:
        conn = get_db_connection()
        if not conn:
            return []
        cursor = conn.cursor(dictionary=True)
        
        query = "SELECT * FROM packages WHERE is_active = 1"
        params = []
        
        if category:
            query += " AND category LIKE %s"
            params.append(f"%{category}%")
        if destination:
            query += " AND destination LIKE %s"
            params.append(f"%{destination}%")
        
        cursor.execute(query, params)
        packages = cursor.fetchall()
        
        cursor.close()
        conn.close()
        return packages
    except Exception as e:
        print(f"Error fetching packages: {e}")
        return []


def get_package_by_id(package_id):
    """Get package by ID"""
    try:
        conn = get_db_connection()
        if not conn:
            return None
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM packages WHERE id = %s", (package_id,))
        package = cursor.fetchone()
        cursor.close()
        conn.close()
        return package
    except Exception as e:
        print(f"Error fetching package: {e}")
        return None


def update_package(package_id, data):
    """Update package"""
    try:
        conn = get_db_connection()
        if not conn:
            return False
        
        cursor = conn.cursor()
        query = """UPDATE packages SET title = %s, description = %s, destination = %s,
                   duration = %s, price = %s, category = %s, is_active = %s WHERE id = %s"""
        
        cursor.execute(query, (
            data.get('title'), data.get('description'), data.get('destination'),
            data.get('duration'), data.get('price'), data.get('category'),
            data.get('is_active', 1), package_id
        ))
        
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Error updating package: {e}")
        return False


def delete_package(package_id):
    """Delete package (soft delete)"""
    try:
        conn = get_db_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        cursor.execute("UPDATE packages SET is_active = 0 WHERE id = %s", (package_id,))
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Error deleting package: {e}")
        return False


# ==================== TRAINS DATABASE FUNCTIONS ====================
def get_all_trains(origin=None, destination=None):
    """Get all trains with optional filtering"""
    try:
        conn = get_db_connection()
        if not conn:
            return []
        cursor = conn.cursor(dictionary=True)
        
        query = "SELECT * FROM trains WHERE is_active = 1"
        params = []
        
        if origin:
            query += " AND origin LIKE %s"
            params.append(f"%{origin}%")
        if destination:
            query += " AND destination LIKE %s"
            params.append(f"%{destination}%")
        
        cursor.execute(query, params)
        trains = cursor.fetchall()
        
        cursor.close()
        conn.close()
        return trains
    except Exception as e:
        print(f"Error fetching trains: {e}")
        return []


def get_train_by_id(train_id):
    """Get train by ID"""
    try:
        conn = get_db_connection()
        if not conn:
            return None
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM trains WHERE id = %s", (train_id,))
        train = cursor.fetchone()
        cursor.close()
        conn.close()
        return train
    except Exception as e:
        print(f"Error fetching train: {e}")
        return None


def update_train(train_id, data):
    """Update train"""
    try:
        conn = get_db_connection()
        if not conn:
            return {'success': False, 'message': 'Database connection failed'}
        
        cursor = conn.cursor(dictionary=True)
        
        # Get current train data
        cursor.execute("SELECT * FROM trains WHERE id = %s", (train_id,))
        current = cursor.fetchone()
        
        if not current:
            cursor.close()
            conn.close()
            return {'success': False, 'message': 'Train not found'}
        
        # Merge current data with updates
        query = """UPDATE trains SET train_code = %s, train_name = %s, train_number = %s,
                   origin = %s, destination = %s, departure_time = %s, arrival_time = %s,
                   duration = %s, price = %s, available_seats = %s, is_active = %s WHERE id = %s"""
        
        cursor.execute(query, (
            data.get('train_code', current['train_code']),
            data.get('train_name', current['train_name']),
            data.get('train_number', current['train_number']),
            data.get('origin', current['origin']),
            data.get('destination', current['destination']),
            data.get('departure_time', current['departure_time']),
            data.get('arrival_time', current['arrival_time']),
            data.get('duration', current['duration']),
            data.get('price', current['price']),
            data.get('available_seats', current['available_seats']),
            data.get('is_active', current['is_active']),
            train_id
        ))
        
        conn.commit()
        cursor.close()
        conn.close()
        return {'success': True}
    except Exception as e:
        return {'success': False, 'message': str(e)}


def delete_train(train_id):
    """Delete train (soft delete)"""
    try:
        conn = get_db_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        cursor.execute("UPDATE trains SET is_active = 0 WHERE id = %s", (train_id,))
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Error deleting train: {e}")
        return False


# ==================== SAVED ITEMS DATABASE FUNCTIONS ====================
def add_saved_item(user_email, item_type, item_id):
    """Add an item to user's saved list"""
    try:
        conn = get_db_connection()
        if not conn:
            return {'success': False, 'message': 'Database connection failed'}
        
        cursor = conn.cursor(dictionary=True)
        
        # Get user_id from email
        cursor.execute("SELECT id FROM users WHERE email = %s", (user_email,))
        user = cursor.fetchone()
        
        if not user:
            cursor.close()
            conn.close()
            return {'success': False, 'message': 'User not found'}
        
        user_id = user['id']
        
        # Check if item already saved
        check_query = """
            SELECT id FROM saved 
            WHERE user_id = %s AND item_type = %s AND item_id = %s
        """
        cursor.execute(check_query, (user_id, item_type, item_id))
        existing = cursor.fetchone()
        
        if existing:
            cursor.close()
            conn.close()
            return {'success': False, 'message': 'Item already saved'}
        
        # Insert new saved item
        insert_query = """
            INSERT INTO saved (user_id, item_type, item_id)
            VALUES (%s, %s, %s)
        """
        cursor.execute(insert_query, (user_id, item_type, item_id))
        conn.commit()
        
        cursor.close()
        conn.close()
        return {'success': True}
    except Exception as e:
        return {'success': False, 'message': str(e)}


def get_saved_items(user_email):
    """Get all saved items for a user with full details"""
    try:
        conn = get_db_connection()
        if not conn:
            return []
        
        cursor = conn.cursor(dictionary=True)
        
        # Get user_id from email
        cursor.execute("SELECT id FROM users WHERE email = %s", (user_email,))
        user = cursor.fetchone()
        
        if not user:
            cursor.close()
            conn.close()
            return []
        
        user_id = user['id']
        
        # Fetch saved items
        query = """
            SELECT item_type, item_id, created_at 
            FROM saved 
            WHERE user_id = %s 
            ORDER BY created_at DESC
        """
        cursor.execute(query, (user_id,))
        saved_items = cursor.fetchall()
        
        formatted_items = []
        
        for item in saved_items:
            item_type = item['item_type']
            item_id = item['item_id']
            
            # Fetch full details based on type
            if item_type == 'package':
                cursor.execute("""
                    SELECT id, title, destination, duration, price, image_url 
                    FROM packages WHERE id = %s
                """, (item_id,))
                details = cursor.fetchone()
                if details:
                    formatted_items.append({
                        'type': 'package',
                        'id': details['id'],
                        'title': details['title'],
                        'image': details['image_url'],
                        'destination': details['destination'],
                        'duration': details['duration'],
                        'price': float(details['price']),
                        'savedAt': item['created_at'].isoformat()
                    })
                    
            elif item_type == 'hotel':
                cursor.execute("""
                    SELECT id, name, city, rating, price_per_night, image_url 
                    FROM hotels WHERE id = %s
                """, (item_id,))
                details = cursor.fetchone()
                if details:
                    formatted_items.append({
                        'type': 'hotel',
                        'id': details['id'],
                        'title': details['name'],
                        'image': details['image_url'],
                        'city': details['city'],
                        'rating': float(details['rating']),
                        'price': float(details['price_per_night']),
                        'savedAt': item['created_at'].isoformat()
                    })
                    
            elif item_type == 'flight':
                cursor.execute("""
                    SELECT id, airline_name, origin, destination, price, departure_time 
                    FROM flights WHERE id = %s
                """, (item_id,))
                details = cursor.fetchone()
                if details:
                    formatted_items.append({
                        'type': 'flight',
                        'id': details['id'],
                        'title': f"{details['airline_name']} - {details['origin']} to {details['destination']}",
                        'image': 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05',
                        'destination': details['destination'],
                        'price': float(details['price']),
                        'savedAt': item['created_at'].isoformat()
                    })
                    
            elif item_type == 'train':
                cursor.execute("""
                    SELECT id, train_name, origin, destination, price, departure_time 
                    FROM trains WHERE id = %s
                """, (item_id,))
                details = cursor.fetchone()
                if details:
                    formatted_items.append({
                        'type': 'train',
                        'id': details['id'],
                        'title': f"{details['train_name']} - {details['origin']} to {details['destination']}",
                        'image': 'https://images.unsplash.com/photo-1474487548417-781cb71495f3',
                        'destination': details['destination'],
                        'price': float(details['price']),
                        'savedAt': item['created_at'].isoformat()
                    })
        
        cursor.close()
        conn.close()
        return formatted_items
    except Exception as e:
        print(f"Error fetching saved items: {e}")
        return []


def delete_saved_item(user_email, item_type, item_id):
    """Delete a saved item"""
    try:
        conn = get_db_connection()
        if not conn:
            return {'success': False, 'message': 'Database connection failed'}
        
        cursor = conn.cursor(dictionary=True)
        
        # Get user_id from email
        cursor.execute("SELECT id FROM users WHERE email = %s", (user_email,))
        user = cursor.fetchone()
        
        if not user:
            cursor.close()
            conn.close()
            return {'success': False, 'message': 'User not found'}
        
        user_id = user['id']
        
        # Delete saved item
        query = """
            DELETE FROM saved 
            WHERE user_id = %s AND item_type = %s AND item_id = %s
        """
        cursor.execute(query, (user_id, item_type, item_id))
        conn.commit()
        
        cursor.close()
        conn.close()
        return {'success': True}
    except Exception as e:
        return {'success': False, 'message': str(e)}


# ==================== ANALYTICS DATABASE FUNCTIONS ====================
def get_admin_stats():
    """Get dashboard statistics"""
    try:
        conn = get_db_connection()
        if not conn:
            return {}
        
        cursor = conn.cursor(dictionary=True)
        stats = {}
        
        # Total users
        cursor.execute("SELECT COUNT(*) as count FROM users WHERE is_active = 1")
        stats['total_users'] = cursor.fetchone()['count']
        
        # Total bookings
        cursor.execute("SELECT COUNT(*) as count FROM bookings")
        stats['total_bookings'] = cursor.fetchone()['count']
        
        # Total revenue
        cursor.execute("SELECT COALESCE(SUM(total_price), 0) as revenue FROM bookings WHERE payment_status = 'completed'")
        stats['total_revenue'] = float(cursor.fetchone()['revenue'])
        
        # Pending bookings
        cursor.execute("SELECT COUNT(*) as count FROM bookings WHERE status = 'pending'")
        stats['pending_bookings'] = cursor.fetchone()['count']
        
        # Bookings by type
        cursor.execute("SELECT booking_type, COUNT(*) as count FROM bookings GROUP BY booking_type")
        stats['bookings_by_type'] = {row['booking_type']: row['count'] for row in cursor.fetchall()}
        
        cursor.close()
        conn.close()
        return stats
    except Exception as e:
        print(f"Error fetching stats: {e}")
        return {}


def get_analytics_data(start_date='2026-01-01', end_date='2026-12-31'):
    """Get comprehensive analytics data with date filtering"""
    try:
        conn = get_db_connection()
        if not conn:
            return {}
        
        cursor = conn.cursor(dictionary=True)
        analytics = {}
        
        # Revenue Analytics
        cursor.execute("""
            SELECT 
                COALESCE(SUM(CASE WHEN payment_status = 'completed' THEN total_price ELSE 0 END), 0) as total_revenue,
                COALESCE(SUM(CASE WHEN payment_status = 'pending' THEN total_price ELSE 0 END), 0) as pending_revenue,
                COALESCE(SUM(CASE WHEN payment_status = 'refunded' THEN total_price ELSE 0 END), 0) as refunded_amount,
                COALESCE(AVG(CASE WHEN payment_status = 'completed' THEN total_price END), 0) as avg_booking_value,
                COUNT(CASE WHEN payment_status = 'completed' THEN 1 END) as completed_bookings,
                COUNT(CASE WHEN payment_status = 'failed' THEN 1 END) as failed_payments
            FROM bookings 
            WHERE booking_date BETWEEN %s AND %s
        """, (start_date, end_date))
        revenue_data = cursor.fetchone()
        analytics['revenue'] = {
            'total': float(revenue_data['total_revenue']),
            'pending': float(revenue_data['pending_revenue']),
            'refunded': float(revenue_data['refunded_amount']),
            'average_value': float(revenue_data['avg_booking_value']),
            'completed_count': revenue_data['completed_bookings'],
            'failed_count': revenue_data['failed_payments']
        }
        
        # Revenue by booking type
        cursor.execute("""
            SELECT booking_type, 
                   COALESCE(SUM(CASE WHEN payment_status = 'completed' THEN total_price ELSE 0 END), 0) as revenue,
                   COUNT(*) as count
            FROM bookings 
            WHERE booking_date BETWEEN %s AND %s
            GROUP BY booking_type
        """, (start_date, end_date))
        analytics['revenue_by_type'] = {row['booking_type']: {
            'revenue': float(row['revenue']), 
            'count': row['count']
        } for row in cursor.fetchall()}
        
        # Bookings over time
        cursor.execute("""
            SELECT DATE(booking_date) as date, 
                   COUNT(*) as count,
                   COALESCE(SUM(CASE WHEN payment_status = 'completed' THEN total_price ELSE 0 END), 0) as revenue
            FROM bookings 
            WHERE booking_date BETWEEN %s AND %s
            GROUP BY DATE(booking_date)
            ORDER BY date
        """, (start_date, end_date))
        analytics['bookings_timeline'] = [{
            'date': row['date'].strftime('%Y-%m-%d'),
            'count': row['count'],
            'revenue': float(row['revenue'])
        } for row in cursor.fetchall()]
        
        # Status breakdown
        cursor.execute("""
            SELECT status, COUNT(*) as count
            FROM bookings 
            WHERE booking_date BETWEEN %s AND %s
            GROUP BY status
        """, (start_date, end_date))
        analytics['status_breakdown'] = {row['status']: row['count'] for row in cursor.fetchall()}
        
        # Payment status breakdown
        cursor.execute("""
            SELECT payment_status, COUNT(*) as count,
                   COALESCE(SUM(total_price), 0) as total_amount
            FROM bookings 
            WHERE booking_date BETWEEN %s AND %s
            GROUP BY payment_status
        """, (start_date, end_date))
        analytics['payment_breakdown'] = {row['payment_status']: {
            'count': row['count'],
            'amount': float(row['total_amount'])
        } for row in cursor.fetchall()}
        
        # Top customers
        cursor.execute("""
            SELECT u.name, u.email, 
                   COUNT(b.id) as booking_count,
                   COALESCE(SUM(CASE WHEN b.payment_status = 'completed' THEN b.total_price ELSE 0 END), 0) as total_spent
            FROM bookings b
            JOIN users u ON b.user_id = u.id
            WHERE b.booking_date BETWEEN %s AND %s
            GROUP BY u.id, u.name, u.email
            ORDER BY total_spent DESC
            LIMIT 10
        """, (start_date, end_date))
        analytics['top_customers'] = [{
            'name': row['name'],
            'email': row['email'],
            'bookings': row['booking_count'],
            'total_spent': float(row['total_spent'])
        } for row in cursor.fetchall()]
        
        # User registration trends
        cursor.execute("""
            SELECT DATE(created_at) as date, COUNT(*) as count
            FROM users 
            WHERE created_at BETWEEN %s AND %s
            GROUP BY DATE(created_at)
            ORDER BY date
        """, (start_date, end_date))
        analytics['user_registrations'] = [{
            'date': row['date'].strftime('%Y-%m-%d'),
            'count': row['count']
        } for row in cursor.fetchall()]
        
        # Popular booking types
        cursor.execute("""
            SELECT booking_type, COUNT(*) as bookings
            FROM bookings 
            WHERE booking_date BETWEEN %s AND %s
            GROUP BY booking_type
            ORDER BY bookings DESC
        """, (start_date, end_date))
        analytics['popular_types'] = [{
            'type': row['booking_type'],
            'bookings': row['bookings']
        } for row in cursor.fetchall()]
        
        # Average travelers per booking
        cursor.execute("""
            SELECT AVG(num_travelers) as avg_travelers,
                   MAX(num_travelers) as max_travelers
            FROM bookings 
            WHERE booking_date BETWEEN %s AND %s
        """, (start_date, end_date))
        traveler_stats = cursor.fetchone()
        analytics['traveler_stats'] = {
            'average': float(traveler_stats['avg_travelers'] or 0),
            'max': traveler_stats['max_travelers'] or 0
        }
        
        cursor.close()
        conn.close()
        return analytics
    except Exception as e:
        print(f"Error fetching analytics: {e}")
        return {}


# ==================== SAMPLE DATA FUNCTION ====================
def add_sample_bookings_data():
    """
    Utility function to populate database with sample bookings data.
    Run this once to add test data for development/testing.
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        print("Connected to database successfully!")
        
        # Add sample users
        print("\n1. Adding sample users...")
        users_data = [
            ('Rajesh Kumar', 'rajesh.kumar@email.com', '9876543210', 'hashed_password_1'),
            ('Priya Sharma', 'priya.sharma@email.com', '9876543211', 'hashed_password_2'),
            ('Amit Patel', 'amit.patel@email.com', '9876543212', 'hashed_password_3'),
            ('Sneha Gupta', 'sneha.gupta@email.com', '9876543213', 'hashed_password_4'),
            ('Vikram Singh', 'vikram.singh@email.com', '9876543214', 'hashed_password_5'),
            ('Anjali Reddy', 'anjali.reddy@email.com', '9876543215', 'hashed_password_6'),
            ('Rahul Verma', 'rahul.verma@email.com', '9876543216', 'hashed_password_7'),
            ('Kavya Nair', 'kavya.nair@email.com', '9876543217', 'hashed_password_8'),
            ('Arjun Joshi', 'arjun.joshi@email.com', '9876543218', 'hashed_password_9'),
            ('Divya Menon', 'divya.menon@email.com', '9876543219', 'hashed_password_10')
        ]
        
        for user in users_data:
            try:
                cursor.execute(
                    "INSERT INTO users (name, email, phone, password_hash, is_active) VALUES (%s, %s, %s, %s, 1)",
                    user
                )
            except Error as e:
                if 'Duplicate entry' in str(e):
                    print(f"  - User {user[1]} already exists, skipping...")
        
        conn.commit()
        print(f"✓ Users added successfully!")
        
        # Add bookings
        print("\n2. Adding sample bookings...")
        bookings_data = [
            # Flight bookings
            (1, 'flight', '2026-01-15 10:30:00', '2026-02-20 14:00:00', '2026-02-27 09:00:00', 2, 45000.00, 'confirmed', 'completed', 'TB-FLT-001234'),
            (2, 'flight', '2026-01-20 14:45:00', '2026-02-18 08:30:00', '2026-02-25 16:00:00', 1, 18500.00, 'confirmed', 'completed', 'TB-FLT-001235'),
            (3, 'flight', '2026-02-01 09:15:00', '2026-03-10 11:00:00', None, 3, 52000.00, 'pending', 'pending', 'TB-FLT-001236'),
            (4, 'flight', '2026-02-05 16:20:00', '2026-02-25 07:30:00', '2026-03-05 19:00:00', 2, 38000.00, 'confirmed', 'pending', 'TB-FLT-001237'),
            (5, 'flight', '2026-01-28 11:00:00', '2026-02-15 13:45:00', None, 1, 15000.00, 'cancelled', 'refunded', 'TB-FLT-001238'),
            # Hotel bookings
            (6, 'hotel', '2026-01-18 12:30:00', '2026-02-22 14:00:00', '2026-02-26 11:00:00', 2, 24000.00, 'confirmed', 'completed', 'TB-HTL-002341'),
            (7, 'hotel', '2026-02-02 15:45:00', '2026-03-05 15:00:00', '2026-03-10 12:00:00', 4, 35000.00, 'confirmed', 'completed', 'TB-HTL-002342'),
            (1, 'hotel', '2026-02-06 10:15:00', '2026-02-28 16:00:00', '2026-03-03 10:00:00', 2, 18500.00, 'pending', 'pending', 'TB-HTL-002343'),
            (8, 'hotel', '2026-01-25 13:20:00', '2026-02-20 14:00:00', '2026-02-23 11:00:00', 3, 21000.00, 'confirmed', 'pending', 'TB-HTL-002344'),
            (9, 'hotel', '2026-02-03 09:30:00', '2026-03-15 15:00:00', '2026-03-18 12:00:00', 2, 16500.00, 'pending', 'pending', 'TB-HTL-002345'),
            # Package bookings
            (10, 'package', '2026-01-22 11:45:00', '2026-03-01 06:00:00', '2026-03-07 22:00:00', 2, 85000.00, 'confirmed', 'completed', 'TB-PKG-003451'),
            (2, 'package', '2026-02-04 14:15:00', '2026-03-20 08:00:00', '2026-03-27 20:00:00', 4, 156000.00, 'confirmed', 'completed', 'TB-PKG-003452'),
            (3, 'package', '2026-02-07 10:00:00', '2026-04-10 07:00:00', '2026-04-17 21:00:00', 2, 92000.00, 'pending', 'pending', 'TB-PKG-003453'),
            (4, 'package', '2026-01-30 16:30:00', '2026-03-12 06:00:00', '2026-03-18 22:00:00', 3, 127500.00, 'confirmed', 'pending', 'TB-PKG-003454'),
            (5, 'package', '2026-01-19 12:00:00', '2026-02-28 08:00:00', '2026-03-06 20:00:00', 2, 78000.00, 'cancelled', 'failed', 'TB-PKG-003455'),
            # Train bookings
            (6, 'train', '2026-01-24 09:45:00', '2026-02-19 05:30:00', None, 1, 2500.00, 'confirmed', 'completed', 'TB-TRN-004561'),
            (7, 'train', '2026-02-01 13:30:00', '2026-02-25 22:15:00', None, 2, 4800.00, 'confirmed', 'completed', 'TB-TRN-004562'),
            (8, 'train', '2026-02-05 11:20:00', '2026-03-08 06:45:00', None, 3, 6750.00, 'pending', 'pending', 'TB-TRN-004563'),
            (9, 'train', '2026-02-06 15:00:00', '2026-03-01 18:30:00', None, 1, 1850.00, 'confirmed', 'pending', 'TB-TRN-004564'),
            (10, 'train', '2026-01-27 10:30:00', '2026-02-15 14:20:00', None, 2, 4200.00, 'confirmed', 'completed', 'TB-TRN-004565'),
            # Additional mixed bookings
            (1, 'flight', '2026-02-08 08:00:00', '2026-03-15 10:30:00', '2026-03-22 15:00:00', 4, 68000.00, 'pending', 'pending', 'TB-FLT-001239'),
            (2, 'hotel', '2026-02-07 17:45:00', '2026-03-18 14:00:00', '2026-03-21 11:00:00', 2, 19500.00, 'confirmed', 'completed', 'TB-HTL-002346'),
            (3, 'train', '2026-02-08 12:15:00', '2026-02-28 19:45:00', None, 1, 2200.00, 'confirmed', 'completed', 'TB-TRN-004566'),
            (4, 'package', '2026-02-06 14:30:00', '2026-04-01 07:00:00', '2026-04-08 21:00:00', 2, 89000.00, 'pending', 'pending', 'TB-PKG-003456'),
            (5, 'hotel', '2026-02-03 11:45:00', '2026-02-24 15:00:00', '2026-02-27 12:00:00', 3, 22500.00, 'confirmed', 'pending', 'TB-HTL-002347'),
        ]
        
        booking_query = """
            INSERT INTO bookings 
            (user_id, booking_type, booking_date, travel_date, return_date, 
             num_travelers, total_price, status, payment_status, booking_reference)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        
        for booking in bookings_data:
            cursor.execute(booking_query, booking)
        
        conn.commit()
        print(f"✓ {len(bookings_data)} bookings added successfully!")
        
        # Display summary
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM bookings")
        total_bookings = cursor.fetchone()[0]
        
        print(f"\nTotal Users: {total_users}")
        print(f"Total Bookings: {total_bookings}")
        print("\n✓ Sample data added successfully!")
        
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Error adding sample data: {e}")
        return False


# ==================== CONTACT MESSAGES DATABASE FUNCTIONS ====================
def create_contact_message(name, email, topic, message):
    """Create a new contact message"""
    try:
        conn = get_db_connection()
        if not conn:
            return {'success': False, 'message': 'Database connection failed'}
        
        cursor = conn.cursor()
        query = """
            INSERT INTO contact_messages (name, email, topic, message, status, created_at)
            VALUES (%s, %s, %s, %s, 'new', NOW())
        """
        cursor.execute(query, (name, email, topic, message))
        conn.commit()
        
        message_id = cursor.lastrowid
        cursor.close()
        conn.close()
        
        return {
            'success': True,
            'message': 'Contact message submitted successfully',
            'message_id': message_id
        }
    except Exception as e:
        print(f"Error creating contact message: {e}")
        return {'success': False, 'message': str(e)}


def get_all_contact_messages():
    """Get all contact messages (for admin panel)"""
    try:
        conn = get_db_connection()
        if not conn:
            return []
        
        cursor = conn.cursor(dictionary=True)
        query = """
            SELECT id, name, email, topic, message, status, created_at
            FROM contact_messages
            ORDER BY created_at DESC
        """
        cursor.execute(query)
        messages = cursor.fetchall()
        cursor.close()
        conn.close()
        return messages
    except Exception as e:
        print(f"Error fetching contact messages: {e}")
        return []


def update_contact_message_status(message_id, status):
    """Update contact message status"""
    try:
        conn = get_db_connection()
        if not conn:
            return {'success': False, 'message': 'Database connection failed'}
        
        cursor = conn.cursor()
        query = "UPDATE contact_messages SET status = %s WHERE id = %s"
        cursor.execute(query, (status, message_id))
        conn.commit()
        
        cursor.close()
        conn.close()
        
        return {'success': True, 'message': 'Message status updated successfully'}
    except Exception as e:
        print(f"Error updating message status: {e}")
        return {'success': False, 'message': str(e)}


def delete_contact_message(message_id):
    """Delete a contact message"""
    try:
        conn = get_db_connection()
        if not conn:
            return {'success': False, 'message': 'Database connection failed'}
        
        cursor = conn.cursor()
        query = "DELETE FROM contact_messages WHERE id = %s"
        cursor.execute(query, (message_id,))
        conn.commit()
        
        cursor.close()
        conn.close()
        
        return {'success': True, 'message': 'Message deleted successfully'}
    except Exception as e:
        print(f"Error deleting message: {e}")
        return {'success': False, 'message': str(e)}
