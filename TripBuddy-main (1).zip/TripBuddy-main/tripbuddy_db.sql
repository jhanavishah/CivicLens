-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2026 at 03:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tripbuddy_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password_hash`, `created_at`, `is_active`) VALUES
(1, 'Khush Borsania', 'khushborsania1276@gmail.com', 'pbkdf2:sha256:1000000$ISI6ZkCfpjsgjsuz$611d281317819875d332c3722f13f2c8b20a53bca9dbb34423f2114517185dfa', '2026-02-07 19:02:08', 1),
(2, 'Harshil Patel', 'harshil8744@gmail.com', 'pbkdf2:sha256:1000000$iUwaFT9Yo8RgbxHy$a716e72a51c301b8314f95c7f25ebfa4462f0debdf37c4c11973d88a43b2a770', '2026-02-07 19:02:08', 1),
(3, 'Jhanvi Shah', 'jhanvishah1316@gmail.com', 'pbkdf2:sha256:1000000$BSYShsOCqhkl9ZOK$954dd28cd1e3e07e1f36348aa30dcb833e315eadbbcc1a16ce5b53f89f34fd2e', '2026-02-07 19:02:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `booking_type` varchar(20) NOT NULL CHECK (`booking_type` in ('flight','train','package','hotel')),
  `booking_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `travel_date` date NOT NULL,
  `return_date` date DEFAULT NULL,
  `num_travelers` int(11) DEFAULT 1,
  `total_price` decimal(10,2) NOT NULL,
  `status` varchar(20) DEFAULT 'pending' CHECK (`status` in ('pending','confirmed','cancelled')),
  `payment_status` varchar(20) DEFAULT 'pending' CHECK (`payment_status` in ('pending','completed','failed','refunded')),
  `booking_reference` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `booking_type`, `booking_date`, `travel_date`, `return_date`, `num_travelers`, `total_price`, `status`, `payment_status`, `booking_reference`, `created_at`) VALUES
(8, 4, 'package', '2026-02-18 09:26:23', '2027-02-18', '2026-02-21', 2, 55998.00, 'confirmed', 'completed', 'TB-20260218-92753', '2026-02-18 09:26:23'),
(9, 4, 'flight', '2026-02-18 09:55:25', '2026-02-19', NULL, 1, 4704.00, 'cancelled', 'refunded', 'TB-20260218-33537', '2026-02-18 09:55:25'),
(10, 8, 'flight', '2026-02-18 11:50:34', '2026-02-19', NULL, 1, 4704.00, 'confirmed', 'completed', 'TB-20260218-16683', '2026-02-18 11:50:34');

-- --------------------------------------------------------

--
-- Table structure for table `flights`
--

CREATE TABLE `flights` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `airline` varchar(10) NOT NULL,
  `airline_name` varchar(100) NOT NULL,
  `flight_number` varchar(20) DEFAULT NULL,
  `origin` varchar(100) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `origin_code` varchar(10) DEFAULT NULL,
  `destination_code` varchar(10) DEFAULT NULL,
  `departure_time` varchar(20) NOT NULL,
  `arrival_time` varchar(20) NOT NULL,
  `duration` varchar(20) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`features`)),
  `available_seats` int(11) DEFAULT 100,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `flights`
--

INSERT INTO `flights` (`id`, `airline`, `airline_name`, `flight_number`, `origin`, `destination`, `origin_code`, `destination_code`, `departure_time`, `arrival_time`, `duration`, `price`, `category`, `features`, `available_seats`, `is_active`, `created_at`) VALUES
(1, '6E', 'IndiGo', '6E-101', 'Delhi', 'Mumbai', 'DEL', 'BOM', '06:00', '08:15', '2h 15m', 4200.00, 'domestic', '[\"Meal Included\", \"Extra Legroom\"]', 150, 1, '2026-02-02 17:14:23'),
(2, 'AI', 'Air India', 'AI-404', 'Mumbai', 'Bangalore', 'BOM', 'BLR', '09:30', '11:15', '1h 45m', 3800.00, 'domestic', '[\"Wifi\", \"Snacks\"]', 120, 1, '2026-02-02 17:14:23'),
(3, 'SG', 'SpiceJet', 'SG-202', 'Chennai', 'Kolkata', 'MAA', 'CCU', '14:00', '16:30', '2h 30m', 4500.00, 'domestic', '[\"Hot Meals\"]', 140, 1, '2026-02-02 17:14:23'),
(4, 'UK', 'Vistara', 'UK-990', 'Delhi', 'Hyderabad', 'DEL', 'HYD', '18:00', '20:15', '2h 15m', 5100.00, 'domestic', '[\"Premium Economy\", \"Lounge\"]', 160, 1, '2026-02-02 17:14:23'),
(5, 'QP', 'Akasa Air', 'QP-111', 'Bangalore', 'Ahmedabad', 'BLR', 'AMD', '07:45', '09:30', '1h 45m', 3200.00, 'domestic', '[\"USB Charging\"]', 180, 1, '2026-02-02 17:14:23'),
(6, '6E', 'IndiGo', '6E-555', 'Goa', 'Delhi', 'GOI', 'DEL', '13:00', '15:45', '2h 45m', 5600.00, 'domestic', '[\"Flexi Fare\"]', 150, 1, '2026-02-02 17:14:23'),
(7, 'AI', 'Air India', 'AI-202', 'Pune', 'Delhi', 'PNQ', 'DEL', '20:30', '22:45', '2h 15m', 4100.00, 'domestic', '[\"Wifi\"]', 130, 1, '2026-02-02 17:14:23'),
(8, 'I5', 'AirAsia', 'I5-777', 'Kochi', 'Bangalore', 'COK', 'BLR', '10:00', '11:00', '1h 00m', 2500.00, 'domestic', '[\"Low Cost\"]', 180, 1, '2026-02-02 17:14:23'),
(9, 'UK', 'Vistara', 'UK-840', 'Mumbai', 'Jaipur', 'BOM', 'JAI', '08:00', '09:45', '1h 45m', 4900.00, 'domestic', '[\"Meal Included\"]', 140, 1, '2026-02-02 17:14:23'),
(10, 'SG', 'SpiceJet', 'SG-303', 'Ahmedabad', 'Chennai', 'AMD', 'MAA', '15:30', '18:00', '2h 30m', 4600.00, 'domestic', '[\"Priority Check-in\"]', 150, 1, '2026-02-02 17:14:23'),
(11, 'UK', 'Vistara', 'UK-900', 'Delhi', 'Mumbai', 'DEL', 'BOM', '07:00', '09:15', '2h 15m', 15000.00, 'business', '[\"Business Class\", \"Lounge Access\"]', 20, 1, '2026-02-02 17:14:23'),
(12, 'AI', 'Air India', 'AI-550', 'Bangalore', 'Delhi', 'BLR', 'DEL', '17:00', '19:45', '2h 45m', 14500.00, 'business', '[\"Priority Boarding\", \"Gourmet Meal\"]', 25, 1, '2026-02-02 17:14:23'),
(13, 'EK', 'Emirates', 'EK-500', 'Mumbai', 'Dubai', 'BOM', 'DXB', '04:00', '06:00', '3h 30m', 18000.00, 'international', '[\"In-flight Entertainment\", \"Alcohol\"]', 250, 1, '2026-02-02 17:14:23'),
(14, 'SQ', 'Singapore Air', 'SQ-421', 'Mumbai', 'Singapore', 'BOM', 'SIN', '23:00', '07:00', '5h 30m', 22000.00, 'international', '[\"Wifi\", \"2 Meals\"]', 280, 1, '2026-02-02 17:14:23'),
(15, 'BA', 'British Airways', 'BA-198', 'Delhi', 'London', 'DEL', 'LHR', '02:00', '07:30', '9h 00m', 55000.00, 'international', '[\"Extra Baggage\"]', 300, 1, '2026-02-02 17:14:23'),
(16, 'LH', 'Lufthansa', 'LH-755', 'Bangalore', 'Frankfurt', 'BLR', 'FRA', '03:00', '09:00', '9h 30m', 60000.00, 'international', '[\"German Beer\", \"Wifi\"]', 290, 1, '2026-02-02 17:14:23'),
(17, 'TG', 'Thai Airways', 'TG-332', 'Delhi', 'Bangkok', 'DEL', 'BKK', '23:30', '05:00', '4h 00m', 18500.00, 'international', '[\"Hospitality\"]', 260, 1, '2026-02-02 17:14:23'),
(18, 'QR', 'Qatar Airways', 'QR-579', 'Delhi', 'Doha', 'DEL', 'DOH', '04:00', '06:00', '4h 30m', 21000.00, 'international', '[\"Qsuite Experience\"]', 270, 1, '2026-02-02 17:14:23'),
(19, 'AF', 'Air France', 'AF-217', 'Mumbai', 'Paris', 'BOM', 'CDG', '01:00', '07:00', '9h 30m', 58000.00, 'international', '[\"Champagne\"]', 280, 1, '2026-02-02 17:14:23'),
(20, 'JL', 'JAL', 'JL-740', 'Delhi', 'Tokyo', 'DEL', 'HND', '19:00', '06:00', '8h 30m', 65000.00, 'international', '[\"Sushi Meal\"]', 250, 1, '2026-02-02 17:14:23'),
(21, 'MH', 'Malaysia Air', 'MH-174', 'Chennai', 'Kuala Lumpur', 'MAA', 'KUL', '00:30', '07:00', '4h 00m', 16000.00, 'international', '[\"Extra Legroom\"]', 200, 1, '2026-02-02 17:14:23'),
(22, 'ET', 'Ethiopian', 'ET-687', 'Mumbai', 'Addis Ababa', 'BOM', 'ADD', '05:00', '08:00', '5h 30m', 28000.00, 'international', '[\"Stopover Package\"]', 220, 1, '2026-02-02 17:14:23'),
(23, 'EK', 'Emirates', 'EK-501', 'Delhi', 'Dubai', 'DEL', 'DXB', '10:00', '12:30', '4h 00m', 45000.00, 'business', '[\"Chauffeur Drive\", \"Flat Bed\"]', 40, 1, '2026-02-02 17:14:23'),
(24, 'SQ', 'Singapore Air', 'SQ-422', 'Delhi', 'Singapore', 'DEL', 'SIN', '22:00', '06:00', '5h 30m', 52000.00, 'business', '[\"Book the Cook\"]', 30, 1, '2026-02-02 17:14:23'),
(25, 'VS', 'Virgin Atlantic', 'VS-301', 'Delhi', 'London', 'DEL', 'LHR', '02:30', '07:00', '9h 00m', 120000.00, 'business', '[\"Upper Class Suite\"]', 25, 1, '2026-02-02 17:14:23'),
(26, '6E', 'IndiGo', '6E-601', 'Indore', 'Bangalore', 'IDR', 'BLR', '12:00', '13:45', '1h 45m', 3400.00, 'domestic', '[\"Standard\"]', 150, 1, '2026-02-02 17:14:23'),
(27, 'SG', 'SpiceJet', 'SG-404', 'Jaipur', 'Goa', 'JAI', 'GOI', '11:00', '13:00', '2h 00m', 4100.00, 'domestic', '[\"Hot Meals\"]', 140, 1, '2026-02-02 17:14:23'),
(28, 'UK', 'Vistara', 'UK-870', 'Hyderabad', 'Bangalore', 'HYD', 'BLR', '09:00', '10:15', '1h 15m', 3200.00, 'domestic', '[\"Wifi\"]', 160, 1, '2026-02-02 17:14:23'),
(29, 'AI', 'Air India', 'AI-808', 'Bangalore', 'Mumbai', 'BLR', 'BOM', '16:00', '17:45', '1h 45m', 4200.00, 'domestic', '[\"New Seats\"]', 130, 1, '2026-02-02 17:14:23'),
(30, '6E', 'IndiGo', '6E-222', 'Lucknow', 'Delhi', 'IDR', 'DEL', '08:30', '09:45', '1h 15m', 2800.00, 'domestic', '[\"Saver\"]', 180, 1, '2026-02-02 17:14:23'),
(31, 'QP', 'Akasa Air', 'QP-115', 'Mumbai', 'Chennai', 'BOM', 'MAA', '14:30', '16:30', '2h 00m', 3700.00, 'domestic', '[\"USB Power\"]', 170, 1, '2026-02-02 17:14:23'),
(32, 'I5', 'AirAsia', 'I5-999', 'Delhi', 'Bagdogra', 'DEL', 'IXB', '11:00', '13:00', '2h 00m', 5500.00, 'domestic', '[\"Hill View\"]', 150, 1, '2026-02-02 17:14:23'),
(33, 'SG', 'SpiceJet', 'SG-707', 'Kolkata', 'Guwahati', 'CCU', 'GAU', '10:00', '11:15', '1h 15m', 2900.00, 'domestic', '[\"Short Haul\"]', 160, 1, '2026-02-02 17:14:23'),
(34, '6E', 'IndiGo', '6E-333', 'Patna', 'Mumbai', 'LKO', 'BOM', '17:00', '19:30', '2h 30m', 4800.00, 'domestic', '[\"Direct\"]', 150, 1, '2026-02-02 17:14:23'),
(35, 'AI', 'Air India', 'AI-450', 'Delhi', 'Amritsar', 'DEL', 'ATQ', '06:00', '07:15', '1h 15m', 3100.00, 'domestic', '[\"Breakfast\"]', 140, 1, '2026-02-02 17:14:23'),
(36, 'UK', 'Vistara', 'UK-620', 'Mumbai', 'Kochi', 'BOM', 'COK', '13:00', '15:00', '2h 00m', 4300.00, 'domestic', '[\"Premium Economy\"]', 150, 1, '2026-02-02 17:14:23'),
(37, 'QP', 'Akasa Air', 'QP-101', 'Bangalore', 'Pune', 'BLR', 'PNQ', '19:00', '20:15', '1h 15m', 2600.00, 'domestic', '[\"New Plane\"]', 180, 1, '2026-02-02 17:14:23'),
(38, '6E', 'IndiGo', '6E-800', 'Delhi', 'Varanasi', 'DEL', 'VNS', '15:00', '16:15', '1h 15m', 3200.00, 'domestic', '[\"Spiritual Trip\"]', 160, 1, '2026-02-02 17:14:23'),
(39, 'SG', 'SpiceJet', 'SG-505', 'Chennai', 'Port Blair', 'MAA', 'IXZ', '05:00', '07:15', '2h 15m', 6500.00, 'domestic', '[\"Island View\"]', 140, 1, '2026-02-02 17:14:23'),
(40, 'AI', 'Air India', 'AI-111', 'Delhi', 'Srinagar', 'DEL', 'ATQ', '09:00', '10:30', '1h 30m', 4000.00, 'domestic', '[\"Snow View\"]', 150, 1, '2026-02-02 17:14:23'),
(41, 'EY', 'Etihad', 'EY-206', 'Mumbai', 'Abu Dhabi', 'BOM', 'AUH', '05:00', '07:00', '3h 30m', 19000.00, 'international', '[\"Wifi\"]', 200, 1, '2026-02-02 17:14:23'),
(42, 'TK', 'Turkish', 'TK-717', 'Delhi', 'Istanbul', 'DEL', 'IST', '06:00', '10:30', '6h 00m', 42000.00, 'international', '[\"Stopover\", \"Meal\"]', 250, 1, '2026-02-02 17:14:23'),
(43, 'CX', 'Cathay', 'CX-698', 'Delhi', 'Hong Kong', 'DEL', 'HKG', '22:30', '06:30', '5h 30m', 38000.00, 'international', '[\"Asian Meal\"]', 260, 1, '2026-02-02 17:14:23'),
(44, 'GF', 'Gulf Air', 'GF-065', 'Kochi', 'Bahrain', 'COK', 'BAH', '04:00', '06:00', '4h 30m', 18000.00, 'international', '[\"Extra Bags\"]', 200, 1, '2026-02-02 17:14:23'),
(45, 'KU', 'Kuwait Air', 'KU-302', 'Mumbai', 'Kuwait', 'BOM', 'KWI', '06:30', '08:30', '4h 30m', 17500.00, 'international', '[\"Wifi\"]', 180, 1, '2026-02-02 17:14:23'),
(46, 'WY', 'Oman Air', 'WY-202', 'Chennai', 'Muscat', 'MAA', 'MCT', '08:00', '10:30', '4h 00m', 16000.00, 'international', '[\"Low Fare\"]', 190, 1, '2026-02-02 17:14:23'),
(47, 'FZ', 'FlyDubai', 'FZ-444', 'Delhi', 'Dubai', 'DEL', 'DXB', '10:00', '12:30', '4h 00m', 14000.00, 'international', '[\"Budget\"]', 180, 1, '2026-02-02 17:14:23'),
(48, 'J9', 'Jazeera', 'J9-402', 'Ahmedabad', 'Kuwait', 'AMD', 'KWI', '04:00', '06:00', '4h 30m', 15000.00, 'international', '[\"Standard\"]', 170, 1, '2026-02-02 17:14:23'),
(49, 'UL', 'SriLankan', 'UL-168', 'Chennai', 'Colombo', 'MAA', 'CMB', '09:00', '10:15', '1h 15m', 8000.00, 'international', '[\"Island Hop\"]', 150, 1, '2026-02-02 17:14:23'),
(50, 'KB', 'Druk Air', 'KB-200', 'Kolkata', 'Paro', 'CCU', 'PBH', '10:00', '11:00', '1h 00m', 9000.00, 'international', '[\"Mountain Landing\"]', 120, 1, '2026-02-02 17:14:23'),
(51, 'RA', 'Nepal Air', 'RA-206', 'Delhi', 'Kathmandu', 'DEL', 'KTM', '11:00', '12:45', '1h 45m', 7500.00, 'international', '[\"Himalaya View\"]', 130, 1, '2026-02-02 17:14:23'),
(52, 'BG', 'Biman', 'BG-092', 'Kolkata', 'Dhaka', 'CCU', 'DAC', '08:00', '09:00', '0h 45m', 6000.00, 'international', '[\"Short Haul\"]', 140, 1, '2026-02-02 17:14:23'),
(53, 'D7', 'AirAsia X', 'D7-183', 'Delhi', 'Kuala Lumpur', 'DEL', 'KUL', '23:00', '07:00', '5h 30m', 18000.00, 'international', '[\"Flat Bed Option\"]', 250, 1, '2026-02-02 17:14:23'),
(54, 'TR', 'Scoot', 'TR-505', 'Chennai', 'Singapore', 'MAA', 'SIN', '01:30', '08:30', '4h 30m', 13000.00, 'international', '[\"Budget\"]', 240, 1, '2026-02-02 17:14:23'),
(55, 'VJ', 'VietJet', 'VJ-896', 'Delhi', 'Hanoi', 'DEL', 'HAN', '00:05', '06:00', '4h 30m', 15000.00, 'international', '[\"Beach Trip\"]', 200, 1, '2026-02-02 17:14:23'),
(56, '6E', 'IndiGo', '6E-1001', 'Mumbai', 'Maldives', 'BOM', 'MLE', '10:00', '12:30', '2h 30m', 12000.00, 'international', '[\"Honeymoon\"]', 180, 1, '2026-02-02 17:14:23'),
(57, 'SG', 'SpiceJet', 'SG-055', 'Delhi', 'Dubai', 'DEL', 'DXB', '20:00', '22:30', '4h 00m', 11000.00, 'international', '[\"Budget\"]', 170, 1, '2026-02-02 17:14:23'),
(58, 'IX', 'Air India Ex', 'IX-200', 'Kochi', 'Dubai', 'COK', 'DXB', '14:00', '16:30', '4h 00m', 10500.00, 'international', '[\"Meal Included\"]', 160, 1, '2026-02-02 17:14:23'),
(59, 'G9', 'Air Arabia', 'G9-400', 'Jaipur', 'Sharjah', 'JAI', 'SHJ', '05:00', '07:00', '3h 30m', 14000.00, 'international', '[\"Transit\"]', 180, 1, '2026-02-02 17:14:23'),
(60, 'QV', 'Lao Airlines', 'QV-200', 'Delhi', 'Vientiane', 'DEL', 'VTE', '12:00', '18:00', '4h 30m', 25000.00, 'international', '[\"Exotic\"]', 150, 1, '2026-02-02 17:14:23'),
(61, '6E', 'IndiGo', '6E-102', 'Mumbai', 'Delhi', 'BOM', 'DEL', '18:00', '20:15', '2h 15m', 4300.00, 'domestic', '[\"Evening Flight\"]', 150, 1, '2026-02-02 17:14:23'),
(62, 'AI', 'Air India', 'AI-405', 'Bangalore', 'Mumbai', 'BLR', 'BOM', '14:00', '15:45', '1h 45m', 3900.00, 'domestic', '[\"Afternoon\"]', 120, 1, '2026-02-02 17:14:23'),
(63, 'UK', 'Vistara', 'UK-991', 'Hyderabad', 'Delhi', 'HYD', 'DEL', '06:00', '08:15', '2h 15m', 5200.00, 'domestic', '[\"Morning\"]', 160, 1, '2026-02-02 17:14:23'),
(64, 'QP', 'Akasa Air', 'QP-112', 'Ahmedabad', 'Bangalore', 'AMD', 'BLR', '10:00', '11:45', '1h 45m', 3300.00, 'domestic', '[\"Brunch\"]', 180, 1, '2026-02-02 17:14:23'),
(65, '6E', 'IndiGo', '6E-556', 'Delhi', 'Goa', 'DEL', 'GOI', '09:00', '11:45', '2h 45m', 5800.00, 'domestic', '[\"Holiday\"]', 150, 1, '2026-02-02 17:14:23'),
(66, 'EK', 'Emirates', 'EK-502', 'Dubai', 'Mumbai', 'DXB', 'BOM', '14:00', '19:00', '3h 30m', 19000.00, 'international', '[\"Return\"]', 250, 1, '2026-02-02 17:14:23'),
(67, 'SQ', 'Singapore Air', 'SQ-424', 'Singapore', 'Delhi', 'SIN', 'DEL', '08:00', '11:00', '5h 30m', 23000.00, 'international', '[\"Morning Arrival\"]', 280, 1, '2026-02-02 17:14:23'),
(68, 'BA', 'British Airways', 'BA-199', 'London', 'Delhi', 'LHR', 'DEL', '10:00', '23:30', '9h 00m', 56000.00, 'international', '[\"Night Arrival\"]', 300, 1, '2026-02-02 17:14:23'),
(69, 'LH', 'Lufthansa', 'LH-756', 'Frankfurt', 'Bangalore', 'FRA', 'BLR', '12:00', '01:00', '9h 30m', 62000.00, 'international', '[\"Overnight\"]', 290, 1, '2026-02-02 17:14:23'),
(70, 'QR', 'Qatar Airways', 'QR-580', 'Doha', 'Delhi', 'DOH', 'DEL', '18:00', '02:00', '4h 30m', 22000.00, 'international', '[\"Evening\"]', 270, 1, '2026-02-02 17:14:23'),
(71, 'JL', 'JAL', 'JL-741', 'Tokyo', 'Delhi', 'HND', 'DEL', '10:00', '16:30', '9h 00m', 67000.00, 'international', '[\"Day Flight\"]', 250, 1, '2026-02-02 17:14:23'),
(72, '6E', 'IndiGo', '6E-901', 'Nagpur', 'Pune', 'NAG', 'PNQ', '14:00', '15:15', '1h 15m', 2800.00, 'domestic', '[\"Connect\"]', 160, 1, '2026-02-02 17:14:23'),
(73, 'SG', 'SpiceJet', 'SG-606', 'Surat', 'Delhi', 'STV', 'DEL', '08:00', '09:30', '1h 30m', 3000.00, 'domestic', '[\"Morning\"]', 150, 1, '2026-02-02 17:14:23'),
(74, 'I5', 'AirAsia', 'I5-404', 'Ranchi', 'Kolkata', 'IXR', 'CCU', '12:00', '13:00', '1h 00m', 2400.00, 'domestic', '[\"Quick\"]', 160, 1, '2026-02-02 17:14:23'),
(75, 'AI', 'Air India', 'AI-303', 'Bhopal', 'Mumbai', 'BHO', 'BOM', '16:00', '17:30', '1h 30m', 3800.00, 'domestic', '[\"Evening\"]', 140, 1, '2026-02-02 17:14:23'),
(76, 'UK', 'Vistara', 'UK-550', 'Dehradun', 'Delhi', 'DED', 'DEL', '11:00', '12:00', '1h 00m', 3500.00, 'domestic', '[\"Hill Return\"]', 150, 1, '2026-02-02 17:14:23'),
(77, '6E', 'IndiGo', '6E-707', 'Udaipur', 'Jaipur', 'UDR', 'JAI', '14:00', '15:00', '1h 00m', 2500.00, 'domestic', '[\"Rajasthan Tour\"]', 140, 1, '2026-02-02 17:14:23'),
(78, 'QP', 'Akasa Air', 'QP-202', 'Guwahati', 'Agartala', 'GAU', 'IXA', '10:00', '10:45', '0h 45m', 2200.00, 'domestic', '[\"North East\"]', 130, 1, '2026-02-02 17:14:23'),
(79, 'SG', 'SpiceJet', 'SG-808', 'Madurai', 'Chennai', 'IXM', 'MAA', '18:00', '19:00', '1h 00m', 2600.00, 'domestic', '[\"Temple Tour\"]', 150, 1, '2026-02-02 17:14:23'),
(80, 'AI', 'Air India', 'AI-606', 'Varanasi', 'Mumbai', 'VNS', 'BOM', '13:00', '15:15', '2h 15m', 4800.00, 'domestic', '[\"Pilgrimage\"]', 160, 1, '2026-02-02 17:14:23'),
(81, '6E', 'IndiGo', '6E-205', 'Coimbatore', 'Bangalore', 'CJB', 'BLR', '07:00', '07:45', '0h 45m', 2400.00, 'domestic', '[\"Business\"]', 170, 1, '2026-02-02 17:14:23'),
(82, 'UK', 'Vistara', 'UK-101', 'Chandigarh', 'Mumbai', 'IXC', 'BOM', '15:00', '17:15', '2h 15m', 5500.00, 'domestic', '[\"Direct\"]', 150, 1, '2026-02-02 17:14:23'),
(83, 'I5', 'AirAsia', 'I5-505', 'Bhubaneswar', 'Delhi', 'IXB', 'DEL', '09:00', '11:00', '2h 00m', 3900.00, 'domestic', '[\"Capital\"]', 160, 1, '2026-02-02 17:14:23'),
(84, 'SG', 'SpiceJet', 'SG-909', 'Jodhpur', 'Ahmedabad', 'JDH', 'AMD', '12:00', '13:00', '1h 00m', 3100.00, 'domestic', '[\"Desert Link\"]', 140, 1, '2026-02-02 17:14:23'),
(85, '6E', 'IndiGo', '6E-404', 'Mangalore', 'Bangalore', 'IXE', 'BLR', '16:00', '16:50', '0h 50m', 2300.00, 'domestic', '[\"Coastal\"]', 180, 1, '2026-02-02 17:14:23'),
(86, 'AI', 'Air India', 'AI-707', 'Raipur', 'Delhi', 'RPR', 'DEL', '19:00', '20:45', '1h 45m', 4100.00, 'domestic', '[\"Evening\"]', 150, 1, '2026-02-02 17:14:23');

-- --------------------------------------------------------

--
-- Table structure for table `hotels`
--

CREATE TABLE `hotels` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `address` text DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT NULL,
  `price_per_night` decimal(10,2) NOT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `amenities` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`amenities`)),
  `room_types` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`room_types`)),
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hotels`
--

INSERT INTO `hotels` (`id`, `name`, `city`, `address`, `rating`, `price_per_night`, `image_url`, `amenities`, `room_types`, `is_active`, `created_at`) VALUES
(1, 'Taj Mahal Palace', 'Mumbai', 'Apollo Bunder', 5.0, 25000.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945', '[\"Pool\", \"Spa\", \"Sea View\", \"Bar\"]', '[\"Luxury Suite\", \"Club Room\"]', 1, '2026-02-02 17:14:23'),
(2, 'The Oberoi Udaivilas', 'Udaipur', 'Lake Pichola', 5.0, 45000.00, 'https://images.unsplash.com/photo-1582719508461-905c673771fd', '[\"Lake View\", \"Private Pool\", \"Butler\"]', '[\"Kohinoor Suite\", \"Premier Room\"]', 1, '2026-02-02 17:14:23'),
(3, 'Rambagh Palace', 'Jaipur', 'Bhawani Singh Rd', 5.0, 38000.00, 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb', '[\"Heritage Walk\", \"Spa\", \"Fine Dining\"]', '[\"Royal Suite\", \"Grand Room\"]', 1, '2026-02-02 17:14:23'),
(4, 'ITC Grand Chola', 'Chennai', 'Guindy', 4.8, 15000.00, 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa', '[\"Luxury Spa\", \"Multiple Pools\"]', '[\"Tower Room\", \"ITC One\"]', 1, '2026-02-02 17:14:23'),
(5, 'The Leela Palace', 'Delhi', 'Chanakyapuri', 4.9, 28000.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945', '[\"Rooftop Pool\", \"Art Walk\"]', '[\"Royal Club\", \"Grande Deluxe\"]', 1, '2026-02-02 17:14:23'),
(6, 'Taj Exotica', 'Goa', 'Benaulim', 4.9, 32000.00, 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4', '[\"Private Beach\", \"Golf\", \"Villas\"]', '[\"Garden Villa\", \"Pool Villa\"]', 1, '2026-02-02 17:14:23'),
(7, 'Wildflower Hall', 'Shimla', 'Chharabra', 4.9, 22000.00, 'https://images.unsplash.com/photo-1445019980597-93fa8acb246c', '[\"Mountain View\", \"Spa\", \"Trekking\"]', '[\"Mountain Room\", \"Valley Suite\"]', 1, '2026-02-02 17:14:23'),
(8, 'Umaid Bhawan Palace', 'Jodhpur', 'Circuit House Rd', 5.0, 55000.00, 'https://images.pexels.com/photos/16843425/pexels-photo-16843425.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Museum\", \"Vintage Cars\", \"Pool\"]', '[\"Royal Suite\", \"Palace Room\"]', 1, '2026-02-02 17:14:23'),
(9, 'Kumarakom Lake Resort', 'Kerala', 'Kumarakom', 4.8, 24000.00, 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6', '[\"Houseboat\", \"Ayurveda\", \"Fishing\"]', '[\"Pool Villa\", \"Lake View Room\"]', 1, '2026-02-02 17:14:23'),
(10, 'The Khyber', 'Gulmarg', 'Kashmir', 4.9, 30000.00, 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4', '[\"Snow View\", \"Heated Pool\", \"Skiing\"]', '[\"Himalayan Room\", \"Cottage\"]', 1, '2026-02-02 17:14:23'),
(11, 'Hyatt Regency', 'Delhi', 'Bhikaji Cama Place', 4.5, 12000.00, 'https://images.unsplash.com/photo-1571896349842-6e5c48dc52e3', '[\"Gym\", \"Pool\", \"Bar\"]', '[\"King Room\", \"Twin Room\"]', 1, '2026-02-02 17:14:23'),
(12, 'JW Marriott', 'Bangalore', 'Vittal Mallya Road', 4.6, 14500.00, 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb', '[\"Rooftop Pool\", \"Microbrewery\"]', '[\"Executive Room\", \"Suite\"]', 1, '2026-02-02 17:14:23'),
(13, 'Grand Hyatt', 'Goa', 'Bambolim', 4.6, 18000.00, 'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9', '[\"Casino\", \"Beach Access\", \"Spa\"]', '[\"Grand King\", \"Club Access\"]', 1, '2026-02-02 17:14:23'),
(14, 'Trident', 'Hyderabad', 'HITEC City', 4.5, 9500.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945', '[\"Infinity Pool\", \"Lounge\"]', '[\"Deluxe\", \"Trident Club\"]', 1, '2026-02-02 17:14:23'),
(15, 'Westin', 'Kolkata', 'Rajarhat', 4.6, 10500.00, 'https://images.unsplash.com/photo-1522771753035-1a5b6562f329', '[\"High Rise\", \"Pool\"]', '[\"Guest Room\", \"Westin Club\"]', 1, '2026-02-02 17:14:23'),
(16, 'Sheraton Grand', 'Pune', 'Bund Garden', 4.5, 9000.00, 'https://images.unsplash.com/photo-1445019980597-93fa8acb246c', '[\"City View\", \"Buffet\"]', '[\"Classic\", \"Club\"]', 1, '2026-02-02 17:14:23'),
(17, 'Radisson Blu', 'Kochi', 'Sahodaran Ayyappan', 4.4, 7500.00, 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa', '[\"Seafood\", \"Spa\"]', '[\"Business Class\", \"Superior\"]', 1, '2026-02-02 17:14:23'),
(18, 'Fairmont', 'Jaipur', 'Riico Kukas', 4.6, 16000.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945', '[\"Hot Air Balloon\", \"Pool\"]', '[\"Fairmont Room\", \"Gold Room\"]', 1, '2026-02-02 17:14:23'),
(19, 'Marriott Resort', 'Jaisalmer', 'Sam Road', 4.7, 13500.00, 'https://images.unsplash.com/photo-1582719508461-905c673771fd', '[\"Desert Safari\", \"Pool\"]', '[\"Fort View\", \"Oasis Room\"]', 1, '2026-02-02 17:14:23'),
(20, 'Novotel', 'Ahmedabad', 'SG Highway', 4.3, 7000.00, 'https://images.unsplash.com/photo-1571896349842-6e5c48dc52e3', '[\"Pool\", \"Gym\", \"Buffet\"]', '[\"Premier\", \"Suite\"]', 1, '2026-02-02 17:14:23'),
(21, 'Lemon Tree', 'Indore', 'RNT Marg', 4.0, 4500.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945', '[\"Wifi\", \"Cafe\", \"Gym\"]', '[\"Superior\", \"Executive\"]', 1, '2026-02-02 17:14:23'),
(22, 'Ginger Hotel', 'Bhubaneswar', 'Jaydev Vihar', 3.8, 3500.00, 'https://images.unsplash.com/photo-1522771753035-1a5b6562f329', '[\"Clean\", \"Wifi\"]', '[\"Twin\", \"Queen\"]', 1, '2026-02-02 17:14:23'),
(23, 'Ibis', 'Nashik', 'Viman Nagar', 3.9, 3800.00, 'https://images.unsplash.com/photo-1445019980597-93fa8acb246c', '[\"Pet Friendly\", \"Bar\"]', '[\"Standard\", \"View\"]', 1, '2026-02-02 17:14:23'),
(24, 'Treebo Trend', 'Nagpur', 'Civil Lines', 3.7, 2800.00, 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa', '[\"Breakfast\", \"Wifi\"]', '[\"Oak\", \"Maple\"]', 1, '2026-02-02 17:14:23'),
(25, 'FabHotel', 'Chandigarh', 'Sector 17', 3.6, 2500.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945', '[\"Parking\", \"AC\"]', '[\"Deluxe\", \"Family\"]', 1, '2026-02-02 17:14:23'),
(26, 'Red Fox', 'Jaipur', 'JLN Marg', 3.9, 3200.00, 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4', '[\"Value\", \"Cafe\"]', '[\"Standard\", \"Superior\"]', 1, '2026-02-02 17:14:23'),
(27, 'Sarovar Portico', 'Ludhiana', 'Bhanpur', 4.1, 4200.00, 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb', '[\"Restaurant\", \"Bar\"]', '[\"Superior\", \"Suite\"]', 1, '2026-02-02 17:14:23'),
(28, 'The Fern', 'Bhavnagar', 'Iscon', 4.2, 3900.00, 'https://images.unsplash.com/photo-1560185007-c5ca9d2c0119', '[\"Eco Friendly\", \"Veg\"]', '[\"Winter Green\", \"Fern Club\"]', 1, '2026-02-02 17:14:23'),
(29, 'Lords Plaza', 'Surat', 'Ring Road', 4.0, 3600.00, 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6', '[\"Rooftop\", \"Pool\"]', '[\"Deluxe\", \"Premium\"]', 1, '2026-02-02 17:14:23'),
(30, 'Fortune Park', 'Vellore', 'Avinashi Rd', 4.1, 4000.00, 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4', '[\"Business\", \"Gym\"]', '[\"Standard\", \"Club\"]', 1, '2026-02-02 17:14:23'),
(31, 'Sterling', 'Puri', 'Sea Beach', 4.1, 5500.00, 'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9', '[\"Beach Access\", \"Library\"]', '[\"Classic\", \"Premiere\"]', 1, '2026-02-02 17:14:23'),
(32, 'Club Mahindra', 'Manali', 'Mashobra', 4.3, 6500.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945', '[\"Activities\", \"Bonfire\"]', '[\"Studio\", \"1BR\"]', 1, '2026-02-02 17:14:23'),
(33, 'Vythiri Resort', 'Wayanad', 'Lakkidi', 4.5, 11000.00, 'https://images.unsplash.com/photo-1522771753035-1a5b6562f329', '[\"Tree House\", \"Nature\"]', '[\"Tree House\", \"Villa\"]', 1, '2026-02-02 17:14:23'),
(34, 'Barefoot', 'Andaman', 'Havelock', 4.8, 18000.00, 'https://images.unsplash.com/photo-1445019980597-93fa8acb246c', '[\"Scuba\", \"Jungle\"]', '[\"Cottage\", \"Tent\"]', 1, '2026-02-02 17:14:23'),
(35, 'Tamara', 'Coorg', 'Kabbinakad', 4.7, 16000.00, 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa', '[\"Plantation Walk\", \"Yoga\"]', '[\"Luxury Cottage\", \"Suite\"]', 1, '2026-02-02 17:14:23'),
(36, 'Evolve Back', 'Kabini', 'Karapura', 4.8, 22000.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945', '[\"Safari\", \"Pool Hut\"]', '[\"Pool Hut\", \"Safari Hut\"]', 1, '2026-02-02 17:14:23'),
(37, 'Ananda', 'Rishikesh', 'Tehri Garhwal', 5.0, 42000.00, 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4', '[\"Wellness\", \"Yoga\"]', '[\"Palace View\", \"Garden View\"]', 1, '2026-02-02 17:14:23'),
(38, 'Mayfair', 'Gangtok', 'Ranipool', 4.6, 12500.00, 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb', '[\"Casino\", \"Spa\"]', '[\"Cottage\", \"Family Room\"]', 1, '2026-02-02 17:14:23'),
(39, 'Ri Kynjai', 'Shillong', 'Umiam Lake', 4.5, 13000.00, 'https://images.unsplash.com/photo-1560185007-c5ca9d2c0119', '[\"Lake View\", \"Khasi Food\"]', '[\"Cottage\", \"Superior\"]', 1, '2026-02-02 17:14:23'),
(40, 'Glenburn', 'Darjeeling', 'Tea Estate', 4.9, 35000.00, 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6', '[\"Tea Tour\", \"Mt Kanchenjunga\"]', '[\"Planter Suite\", \"Rose Suite\"]', 1, '2026-02-02 17:14:23'),
(41, 'The Lalit', 'Chandigarh', 'IT Park', 4.4, 8500.00, 'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9', '[\"Nightclub\", \"Spa\"]', '[\"Deluxe\", \"Suite\"]', 1, '2026-02-02 17:14:23'),
(42, 'Sayaji', 'Rajkot', 'Kalavad Rd', 4.2, 5000.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945', '[\"Grand Buffet\", \"Gym\"]', '[\"Grande\", \"Club\"]', 1, '2026-02-02 17:14:23'),
(43, 'Pride Hotel', 'Bhopal', 'Wardha Rd', 4.0, 4200.00, 'https://images.unsplash.com/photo-1522771753035-1a5b6562f329', '[\"Convention\", \"Wifi\"]', '[\"Deluxe\", \"Superior\"]', 1, '2026-02-02 17:14:23'),
(44, 'Zone by Park', 'Coimbatore', 'Avinashi Rd', 4.1, 3800.00, 'https://images.unsplash.com/photo-1445019980597-93fa8acb246c', '[\"Social\", \"Bar\"]', '[\"Zone Room\", \"Suite\"]', 1, '2026-02-02 17:14:23'),
(45, 'Hometel', 'Roorkee', 'Ferozepur Rd', 3.8, 3000.00, 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa', '[\"Value\", \"Clean\"]', '[\"Standard\", \"Choice\"]', 1, '2026-02-02 17:14:23'),
(46, 'Country Inn', 'Mysore', 'KRS Road', 4.2, 4800.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945', '[\"Pool\", \"Garden\"]', '[\"Deluxe\", \"Suite\"]', 1, '2026-02-02 17:14:23'),
(47, 'Royal Orchid', 'Vadodara', 'Alkapuri', 4.3, 5200.00, 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4', '[\"City Center\", \"Food\"]', '[\"Royal Room\", \"Club\"]', 1, '2026-02-02 17:14:23'),
(48, 'Regenta', 'Dehradun', 'Rajpur Road', 4.1, 4600.00, 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb', '[\"Roof Top\", \"View\"]', '[\"Executive\", \"Premium\"]', 1, '2026-02-02 17:14:23'),
(49, 'Effotel', 'Gurgaon', 'Sector 29', 3.9, 3500.00, 'https://images.unsplash.com/photo-1560185007-c5ca9d2c0119', '[\"Metro Access\", \"Bar\"]', '[\"Smart Room\", \"Studio\"]', 1, '2026-02-02 17:14:23'),
(50, 'Keys Select', 'Thiruvananthapuram', 'Pandit Colony', 3.8, 3200.00, 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6', '[\"Budget\", \"Clean\"]', '[\"Keys Room\", \"Deluxe\"]', 1, '2026-02-02 17:14:23'),
(51, 'Zostel', 'Varanasi', 'Luxa Road', 4.5, 900.00, 'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9', '[\"Dorm\", \"Social\"]', '[\"Bunk Bed\", \"Private\"]', 1, '2026-02-02 17:14:23'),
(52, 'GoStops', 'Agra', 'Taj Ganj', 4.2, 800.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945', '[\"Rooftop\", \"Games\"]', '[\"Dorm\", \"Double\"]', 1, '2026-02-02 17:14:23'),
(53, 'Moustache', 'Rishikesh', 'Tapovan', 4.3, 850.00, 'https://images.unsplash.com/photo-1522771753035-1a5b6562f329', '[\"Yoga\", \"Cafe\"]', '[\"Mixed Dorm\", \"Female Dorm\"]', 1, '2026-02-02 17:14:23'),
(54, 'Backpacker Panda', 'Udaipur', 'Chandpole', 4.1, 750.00, 'https://images.unsplash.com/photo-1445019980597-93fa8acb246c', '[\"Lake View\", \"Cheap\"]', '[\"Bed\", \"Room\"]', 1, '2026-02-02 17:14:23'),
(55, 'The Hosteller', 'Kasol', 'Old Kasol', 4.4, 950.00, 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa', '[\"Mountain Vibes\", \"Fire\"]', '[\"Dorm\", \"Private\"]', 1, '2026-02-02 17:14:23'),
(56, 'Alt Life', 'Manali', 'Old Manali', 4.3, 1000.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945', '[\"River\", \"Workation\"]', '[\"Bed\", \"Cottage\"]', 1, '2026-02-02 17:14:23'),
(57, 'Hornbill', 'Gokarna', 'Chalal', 4.0, 1200.00, 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4', '[\"Beach\", \"Party\"]', '[\"Hut\", \"Room\"]', 1, '2026-02-02 17:14:23'),
(58, 'Trippr', 'Gokarna', 'Middle Beach', 4.1, 1100.00, 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb', '[\"Sea View\", \"Shack\"]', '[\"Dorm\", \"Tent\"]', 1, '2026-02-02 17:14:23'),
(59, 'Nomads', 'Pushkar', 'Chole', 4.2, 900.00, 'https://images.unsplash.com/photo-1560185007-c5ca9d2c0119', '[\"Desert\", \"Pool\"]', '[\"Dorm\", \"Room\"]', 1, '2026-02-02 17:14:23'),
(60, 'Madpackers', 'Amritsar', 'Golden Temple Rd', 4.3, 850.00, 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6', '[\"Near Temple\", \"Social\"]', '[\"Bed\", \"Private\"]', 1, '2026-02-02 17:14:23');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `destination` varchar(100) DEFAULT NULL,
  `duration` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `badge` varchar(50) DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`features`)),
  `inclusions` text DEFAULT NULL,
  `exclusions` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `title`, `description`, `destination`, `duration`, `price`, `category`, `badge`, `image_url`, `features`, `inclusions`, `exclusions`, `is_active`, `created_at`) VALUES
(1, 'Goa Beach Escape', 'Relax on the sunny beaches of Goa', 'Goa', '4 Days', 24999.00, 'beach', 'Popular', 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2', '[\"Flight\", \"Breakfast\", \"Transfers\"]', 'Flights, Hotel, Breakfast', 'Lunch, Dinner', 1, '2026-02-02 17:14:23'),
(2, 'Andaman Island Bliss', 'Explore Havelock and Neil Islands', 'Andaman', '6 Days', 45000.00, 'beach', 'Bestseller', 'https://images.pexels.com/photos/240526/pexels-photo-240526.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Scuba\", \"Ferry\", \"Villa\"]', 'Ferry, Stay, Breakfast', 'Water Sports', 1, '2026-02-02 17:14:23'),
(3, 'Kerala Backwaters & Beach', 'Houseboat and Kovalam beach combo', 'Kerala', '5 Days', 28000.00, 'beach', 'Romantic', 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944', '[\"Houseboat\", \"Beach\", \"Spa\"]', 'All Meals in Houseboat', 'Flights', 1, '2026-02-02 17:14:23'),
(4, 'Maldives Luxury', 'Overwater villa experience', 'Maldives', '5 Days', 85000.00, 'beach', 'Luxury', 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8', '[\"Seaplane\", \"All Inclusive\"]', 'Drinks, Meals, Stay', 'Tips', 1, '2026-02-02 17:14:23'),
(5, 'Pondicherry French Vibes', 'Heritage walk and Auroville', 'Pondicherry', '3 Days', 15000.00, 'beach', 'Weekend', 'https://images.pexels.com/photos/15726207/pexels-photo-15726207.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Heritage\", \"Beach\"]', 'Stay, Breakfast', 'Travel', 1, '2026-02-02 17:14:23'),
(6, 'Bali Fun', 'Seminyak and Ubud tour', 'Bali', '6 Days', 55000.00, 'beach', 'International', 'https://images.unsplash.com/photo-1537996194471-e657df975ab4', '[\"Swing\", \"Temples\", \"Beach\"]', 'Visa, Stay, Tours', 'Lunch', 1, '2026-02-02 17:14:23'),
(7, 'Lakshadweep Coral', 'Crystal clear waters and coral reefs', 'Lakshadweep', '5 Days', 42000.00, 'beach', 'Exotic', 'https://images.unsplash.com/photo-1590523277543-a94d2e4eb00b', '[\"Snorkeling\", \"Island Hop\"]', 'Permit, Stay, Food', 'Flight', 1, '2026-02-02 17:14:23'),
(8, 'Gokarna Beach Trek', 'Om Beach and Kudle Beach trek', 'Gokarna', '3 Days', 8000.00, 'beach', 'Budget', 'https://images.unsplash.com/photo-1614531341773-3bff8b7cb3fc', '[\"Camping\", \"Trek\"]', 'Tent, Guide, Dinner', 'Travel', 1, '2026-02-02 17:14:23'),
(9, 'Sri Lanka Coast', 'Bentota and Mirissa beaches', 'Sri Lanka', '5 Days', 35000.00, 'beach', 'Deal', 'https://images.pexels.com/photos/1007427/pexels-photo-1007427.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Surf\", \"Whales\"]', 'Transport, Stay', 'Visa', 1, '2026-02-02 17:14:23'),
(10, 'Phuket Party', 'Patong beach and Phi Phi island', 'Thailand', '5 Days', 40000.00, 'beach', 'Party', 'https://images.pexels.com/photos/1024967/pexels-photo-1024967.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Nightlife\", \"Island\"]', 'Ferry, Hotel', 'Flights', 1, '2026-02-02 17:14:23'),
(11, 'Shimla Hills Retreat', 'Colonial charm in the Himalayas', 'Shimla', '5 Days', 18499.00, 'hill', 'Family', 'https://images.pexels.com/photos/15516709/pexels-photo-15516709.jpeg?auto=compress&cs=tinysrgb&h=600', '[\"Train\", \"Sightseeing\"]', 'Toy Train, Hotel', 'Lunch', 1, '2026-02-02 17:14:23'),
(12, 'Manali Adventure', 'Solang Valley and Rohtang Pass', 'Manali', '5 Days', 16000.00, 'hill', 'Adventure', 'https://images.pexels.com/photos/3389531/pexels-photo-3389531.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Snow\", \"Paragliding\"]', 'Volvo Bus, Stay', 'Activities', 1, '2026-02-02 17:14:23'),
(13, 'Kashmir Paradise', 'Srinagar, Gulmarg, Pahalgam', 'Kashmir', '6 Days', 32000.00, 'hill', 'Popular', 'https://images.pexels.com/photos/15516709/pexels-photo-15516709.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Shikara\", \"Gondola\"]', 'Houseboat, Car', 'Flights', 1, '2026-02-02 17:14:23'),
(14, 'Darjeeling Tea', 'Tiger Hill sunrise and tea gardens', 'Darjeeling', '4 Days', 14500.00, 'hill', 'Scenic', 'https://images.pexels.com/photos/163231/tea-plantation-mountain-fog-163231.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Sunrise\", \"Monastery\"]', 'Stay, Breakfast', 'Train', 1, '2026-02-02 17:14:23'),
(15, 'Ooty Coffee', 'Plantations and waterfalls', 'Ooty', '3 Days', 12000.00, 'hill', 'Relax', 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad', '[\"Lake\", \"Garden\"]', 'Cottage, Breakfast', 'Travel', 1, '2026-02-02 17:14:23'),
(16, 'Munnar Mist', 'Tea estates of Kerala', 'Munnar', '3 Days', 13000.00, 'hill', 'Nature', 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6', '[\"Trek\", \"View\"]', 'Resort, Dinner', 'Travel', 1, '2026-02-02 17:14:23'),
(17, 'Gangtok & North Sikkim', 'Nathula Pass and lakes', 'Sikkim', '6 Days', 28000.00, 'hill', 'Adventure', 'https://images.pexels.com/photos/14815124/pexels-photo-14815124.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Snow\", \"Yak Ride\"]', 'Permit, Car, Stay', 'Lunch', 1, '2026-02-02 17:14:23'),
(18, 'Leh Ladakh Bike', 'Highest motorable road', 'Ladakh', '8 Days', 35499.00, 'hill', 'Biking', 'https://images.unsplash.com/photo-1469474968028-56623f02e42e', '[\"Bike\", \"Camping\"]', 'Bike, Fuel, Camp', 'Flights', 1, '2026-02-02 17:14:23'),
(19, 'Coorg Staycation', 'Scotland of India', 'Coorg', '3 Days', 15000.00, 'hill', 'Luxury', 'https://images.pexels.com/photos/4321602/pexels-photo-4321602.jpeg?auto=compress&cs=tinysrgb&h=600', '[\"Coffee\", \"Spa\"]', 'Resort, Meals', 'Travel', 1, '2026-02-02 17:14:23'),
(20, 'Nainital Mussoorie', 'Lake tour of Uttarakhand', 'Uttarakhand', '5 Days', 20000.00, 'hill', 'Family', 'https://images.pexels.com/photos/15915444/pexels-photo-15915444.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Boating\", \"Mall Road\"]', 'Car, Hotel', 'Lunch', 1, '2026-02-02 17:14:23'),
(21, 'Rajasthan Royal Tour', 'Jaipur, Jodhpur, Udaipur', 'Rajasthan', '7 Days', 42999.00, 'cultural', 'Bestseller', 'https://images.unsplash.com/photo-1599661046289-e31897846e41', '[\"Forts\", \"Desert\"]', 'Hotels, Car, Guide', 'Flights', 1, '2026-02-02 17:14:23'),
(22, 'Golden Triangle', 'Delhi, Agra, Jaipur', 'North India', '5 Days', 18000.00, 'cultural', 'Classic', 'https://images.unsplash.com/photo-1548013146-72479768bada', '[\"Taj Mahal\", \"History\"]', 'Car, Guide, Stay', 'Tips', 1, '2026-02-02 17:14:23'),
(23, 'Varanasi Spiritual', 'Ganga Aarti and Sarnath', 'Varanasi', '3 Days', 9000.00, 'cultural', 'Religious', 'https://images.unsplash.com/photo-1561361513-2d000a50f0dc', '[\"Boat Ride\", \"Temple\"]', 'Hotel, Boat', 'Train', 1, '2026-02-02 17:14:23'),
(24, 'Hampi Heritage', 'Ruins of Vijayanagara', 'Hampi', '3 Days', 7500.00, 'cultural', 'Backpacker', 'https://images.pexels.com/photos/4412258/pexels-photo-4412258.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Ruins\", \"Coracle\"]', 'Homestay, Bike', 'Food', 1, '2026-02-02 17:14:23'),
(25, 'Mysore Dasara', 'Palace and lights', 'Mysore', '2 Days', 6000.00, 'cultural', 'Festival', 'https://images.pexels.com/photos/10134449/pexels-photo-10134449.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Palace\", \"Zoo\"]', 'Stay, Entry Fees', 'Travel', 1, '2026-02-02 17:14:23'),
(26, 'Khajuraho Temples', 'Erotic temples and falls', 'Khajuraho', '3 Days', 11000.00, 'cultural', 'History', 'https://images.pexels.com/photos/9340625/pexels-photo-9340625.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Temples\", \"Safari\"]', 'Hotel, Guide', 'Train', 1, '2026-02-02 17:14:23'),
(27, 'Ajanta Ellora', 'Cave paintings', 'Aurangabad', '3 Days', 12500.00, 'cultural', 'Art', 'https://images.pexels.com/photos/4032590/pexels-photo-4032590.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Caves\", \"Art\"]', 'Car, Stay', 'Lunch', 1, '2026-02-02 17:14:23'),
(28, 'Amritsar Golden Temple', 'Temple and Border Ceremony', 'Amritsar', '2 Days', 5500.00, 'cultural', 'Short', 'https://images.unsplash.com/photo-1587474260584-136574528ed5', '[\"Wagah\", \"Temple\"]', 'Hotel, Transfer', 'Flight', 1, '2026-02-02 17:14:23'),
(29, 'Madurai Rameshwaram', 'Temple run of South', 'Tamil Nadu', '4 Days', 16000.00, 'cultural', 'Pilgrim', 'https://images.pexels.com/photos/13443171/pexels-photo-13443171.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Temples\", \"Sea\"]', 'Car, Stay', 'Food', 1, '2026-02-02 17:14:23'),
(30, 'Kolkata Durga Puja', 'Festival vibes', 'Kolkata', '4 Days', 14000.00, 'cultural', 'Festive', 'https://images.pexels.com/photos/11029140/pexels-photo-11029140.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Pandals\", \"Food\"]', 'Stay, Guide', 'Travel', 1, '2026-02-02 17:14:23'),
(31, 'Rishikesh Rafting', 'River rafting and camping', 'Rishikesh', '3 Days', 6500.00, 'adventure', 'Thrill', 'https://images.pexels.com/photos/2739013/pexels-photo-2739013.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Rafting\", \"Bungee\"]', 'Camp, Rafting', 'Travel', 1, '2026-02-02 17:14:23'),
(32, 'Jim Corbett Safari', 'Tiger spotting', 'Corbett', '3 Days', 13500.00, 'adventure', 'Wildlife', 'https://images.unsplash.com/photo-1575550959106-5a7defe28b56', '[\"Jeep Safari\", \"Jungle\"]', 'Resort, Safari', 'Travel', 1, '2026-02-02 17:14:23'),
(33, 'Bir Billing', 'Paragliding capital', 'Himachal', '3 Days', 9000.00, 'adventure', 'Fly', 'https://images.unsplash.com/photo-1526772662000-3f88f10405ff', '[\"Paragliding\", \"Trek\"]', 'Camp, Flight', 'Bus', 1, '2026-02-02 17:14:23'),
(34, 'Ranthambore', 'Jungle safari', 'Rajasthan', '3 Days', 15000.00, 'adventure', 'Wildlife', 'https://images.pexels.com/photos/3900437/pexels-photo-3900437.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Tiger\", \"Fort\"]', 'Hotel, Safari', 'Travel', 1, '2026-02-02 17:14:23'),
(35, 'Meghalaya Caving', 'Caves and root bridges', 'Meghalaya', '5 Days', 25000.00, 'adventure', 'Explore', 'https://images.pexels.com/photos/2585465/pexels-photo-2585465.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Caving\", \"Waterfall\"]', 'Car, Stay', 'Flight', 1, '2026-02-02 17:14:23'),
(36, 'Sundarbans', 'Mangroves and tigers', 'West Bengal', '3 Days', 11000.00, 'adventure', 'Nature', 'https://images.pexels.com/photos/9754/mountains-clouds-forest-fog.jpg?auto=compress&cs=tinysrgb&w=800', '[\"Boat\", \"Jungle\"]', 'Boat Stay, Food', 'Train', 1, '2026-02-02 17:14:23'),
(37, 'Spiti Valley', 'Middle land road trip', 'Spiti', '7 Days', 22000.00, 'adventure', 'Roadtrip', 'https://images.pexels.com/photos/1435777/pexels-photo-1435777.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Monastery\", \"Snow\"]', 'Homestay, Car', 'Flight', 1, '2026-02-02 17:14:23'),
(38, 'Kedarnath Trek', 'Pilgrimage trek', 'Kedarnath', '4 Days', 10500.00, 'adventure', 'Trek', 'https://images.pexels.com/photos/13015509/pexels-photo-13015509.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Trek\", \"Temple\"]', 'Camp, Guide', 'Pony', 1, '2026-02-02 17:14:23'),
(39, 'Dandeli Beach & Jungle', 'Best of both worlds', 'Dandeli', '3 Days', 7000.00, 'adventure', 'Budget', 'https://images.unsplash.com/photo-1614531341773-3bff8b7cb3fc', '[\"Watersports\", \"Jungle\"]', 'Tent, Activities', 'Travel', 1, '2026-02-02 17:14:23'),
(40, 'Chadar Trek', 'Frozen river trek', 'Ladakh', '9 Days', 45000.00, 'adventure', 'Extreme', 'https://images.unsplash.com/photo-1469474968028-56623f02e42e', '[\"Ice\", \"Cold\"]', 'Gear, Guide, Food', 'Flights', 1, '2026-02-02 17:14:23'),
(41, 'Dubai Shopping', 'City tour and shopping', 'Dubai', '5 Days', 35000.00, 'adventure', 'Shopping', 'https://images.pexels.com/photos/3767172/pexels-photo-3767172.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Burj Khalifa\", \"Mall\"]', 'Visa, Stay, Tour', 'Flight', 1, '2026-02-02 17:14:23'),
(42, 'Singapore Fun', 'Sentosa and Universal', 'Singapore', '5 Days', 45000.00, 'adventure', 'Family', 'https://images.unsplash.com/photo-1565967511849-76a60a516170', '[\"Theme Park\", \"City\"]', 'Visa, Stay, Entry', 'Flight', 1, '2026-02-02 17:14:23'),
(43, 'Europe Tour', 'Paris, Swiss, Amsterdam', 'Europe', '10 Days', 150000.00, 'cultural', 'Dream', 'https://images.pexels.com/photos/1450372/pexels-photo-1450372.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Eiffel\", \"Snow\"]', 'Hotels, Eurail, Visa', 'Lunch', 1, '2026-02-02 17:14:23'),
(44, 'Vietnam Explorer', 'Hanoi to Ho Chi Minh', 'Vietnam', '7 Days', 48000.00, 'adventure', 'Trending', 'https://images.pexels.com/photos/58597/pexels-photo-58597.jpeg?auto=compress&cs=tinysrgb&w=800', '[\"Halong Bay\", \"History\"]', 'Internal Flights, Stay', 'Intl Flight', 1, '2026-02-02 17:14:23'),
(45, 'Japan Cherry Blossom', 'Tokyo and Kyoto', 'Japan', '7 Days', 120000.00, 'cultural', 'Seasonal', 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e', '[\"Sakura\", \"Bullet Train\"]', 'JR Pass, Stay', 'Flight', 1, '2026-02-02 17:14:23'),
(46, 'Varanasi Spiritual Ghats', 'Experience the mystical Ganga Aarti and narrow lanes.', 'Varanasi', '3 Days', 8500.00, 'cultural', 'Soulful', 'https://images.unsplash.com/photo-1561361513-2d000a50f0dc', '[\"Ganga Aarti\", \"Boat Ride\"]', 'Stay, Breakfast, Boat Ride', 'Flights, Entry fees', 1, '2026-02-18 13:44:51'),
(47, 'Leh Ladakh Heights', 'Explore Pangong Lake and Khardung La Pass.', 'Ladakh', '7 Days', 38000.00, 'adventure', 'Epic', 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da', '[\"Pangong Lake\", \"Oxygen Support\"]', 'Stay, Permits, Transport', 'Flights, Meals', 1, '2026-02-18 13:44:51');

-- --------------------------------------------------------

--
-- Table structure for table `saved`
--

CREATE TABLE `saved` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `item_type` varchar(20) NOT NULL CHECK (`item_type` in ('package','hotel','flight','train')),
  `item_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `saved`
--

INSERT INTO `saved` (`id`, `user_id`, `item_type`, `item_id`, `created_at`) VALUES
(1, 3, 'package', 1, '2026-02-18 07:53:29'),
(2, 3, 'hotel', 10, '2026-02-18 07:53:47'),
(3, 4, 'hotel', 1, '2026-02-18 09:27:15');

-- --------------------------------------------------------

--
-- Table structure for table `trains`
--

CREATE TABLE `trains` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `train_code` varchar(10) NOT NULL,
  `train_name` varchar(100) NOT NULL,
  `train_number` varchar(20) DEFAULT NULL,
  `origin` varchar(100) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `departure_time` varchar(20) NOT NULL,
  `arrival_time` varchar(20) NOT NULL,
  `duration` varchar(20) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `train_class` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`features`)),
  `available_seats` int(11) DEFAULT 100,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trains`
--

INSERT INTO `trains` (`id`, `train_code`, `train_name`, `train_number`, `origin`, `destination`, `departure_time`, `arrival_time`, `duration`, `price`, `train_class`, `category`, `features`, `available_seats`, `is_active`, `created_at`) VALUES
(1, 'RJ', 'Mumbai Rajdhani', '12952', 'Delhi', 'Mumbai', '16:55', '08:35', '15h 40m', 2850.00, 'AC 2-Tier', 'ac2', '[\"Meals\", \"Wifi\"]', 100, 1, '2026-02-02 17:14:23'),
(2, 'RJ', 'Mumbai Rajdhani', '12952', 'Delhi', 'Mumbai', '16:55', '08:35', '15h 40m', 4200.00, 'AC 1st Class', 'ac1', '[\"Coupe\", \"Meals\"]', 20, 1, '2026-02-02 17:14:23'),
(3, 'SH', 'Bhopal Shatabdi', '12002', 'Delhi', 'Bhopal', '06:00', '14:00', '8h 00m', 1500.00, 'AC Chair Car', 'ac1', '[\"Breakfast\", \"Newspaper\"]', 300, 1, '2026-02-02 17:14:23'),
(4, 'SK', 'Sealdah Duronto', '12259', 'Delhi', 'Kolkata', '20:00', '12:30', '16h 30m', 2100.00, 'AC 3-Tier', 'ac3', '[\"Meals\", \"Bedding\"]', 200, 1, '2026-02-02 17:14:23'),
(5, 'RJ', 'Bangalore Rajdhani', '22692', 'Delhi', 'Bangalore', '20:00', '06:30', '34h 30m', 3500.00, 'AC 2-Tier', 'ac2', '[\"Meals\"]', 120, 1, '2026-02-02 17:14:23'),
(6, 'SH', 'Mysore Shatabdi', '12007', 'Chennai', 'Mysore', '06:00', '13:00', '7h 00m', 1100.00, 'AC Chair Car', 'ac1', '[\"Snacks\"]', 250, 1, '2026-02-02 17:14:23'),
(7, 'RJ', 'Dibrugarh Rajdhani', '20503', 'Delhi', 'Guwahati', '11:00', '13:00', '26h 00m', 3100.00, 'AC 2-Tier', 'ac2', '[\"Meals\"]', 100, 1, '2026-02-02 17:14:23'),
(8, 'SK', 'Pune Duronto', '12222', 'Kolkata', 'Pune', '08:00', '11:00', '27h 00m', 2200.00, 'AC 3-Tier', 'ac3', '[\"Meals\"]', 180, 1, '2026-02-02 17:14:23'),
(9, 'RJ', 'Ahmedabad Rajdhani', '12958', 'Delhi', 'Ahmedabad', '18:00', '07:00', '13h 00m', 2400.00, 'AC 2-Tier', 'ac2', '[\"Meals\"]', 110, 1, '2026-02-02 17:14:23'),
(10, 'SH', 'Lucknow Shatabdi', '12004', 'Delhi', 'Lucknow', '06:10', '12:40', '6h 30m', 1300.00, 'AC Chair Car', 'ac1', '[\"Breakfast\"]', 280, 1, '2026-02-02 17:14:23'),
(11, 'GT', 'Goa Express', '12780', 'Delhi', 'Goa', '15:00', '06:30', '39h 30m', 850.00, 'Sleeper', 'sleeper', '[\"Pantry\"]', 300, 1, '2026-02-02 17:14:23'),
(12, 'GT', 'Goa Express', '12780', 'Delhi', 'Goa', '15:00', '06:30', '39h 30m', 2200.00, 'AC 3-Tier', 'ac3', '[\"Bedding\"]', 150, 1, '2026-02-02 17:14:23'),
(13, 'TN', 'Tamil Nadu Exp', '12622', 'Delhi', 'Chennai', '21:00', '06:00', '33h 00m', 900.00, 'Sleeper', 'sleeper', '[\"Pantry\"]', 320, 1, '2026-02-02 17:14:23'),
(14, 'KK', 'Karnataka Exp', '12628', 'Delhi', 'Bangalore', '20:00', '12:00', '40h 00m', 950.00, 'Sleeper', 'sleeper', '[\"Pantry\"]', 300, 1, '2026-02-02 17:14:23'),
(15, 'MN', 'Mangala Exp', '12618', 'Delhi', 'Kochi', '05:00', '10:00', '53h 00m', 1000.00, 'Sleeper', 'sleeper', '[\"Pantry\"]', 280, 1, '2026-02-02 17:14:23'),
(16, 'AV', 'Avantika Exp', '12961', 'Mumbai', 'Indore', '19:00', '09:00', '14h 00m', 600.00, 'Sleeper', 'sleeper', '[\"Clean\"]', 250, 1, '2026-02-02 17:14:23'),
(17, 'AV', 'Avantika Exp', '12961', 'Mumbai', 'Indore', '19:00', '09:00', '14h 00m', 1600.00, 'AC 3-Tier', 'ac3', '[\"Bedding\"]', 120, 1, '2026-02-02 17:14:23'),
(18, 'PS', 'Paschim Exp', '12925', 'Mumbai', 'Amritsar', '12:00', '20:00', '32h 00m', 800.00, 'Sleeper', 'sleeper', '[\"Pantry\"]', 300, 1, '2026-02-02 17:14:23'),
(19, 'KL', 'Kalka Mail', '12311', 'Kolkata', 'Delhi', '19:00', '21:00', '26h 00m', 750.00, 'Sleeper', 'sleeper', '[\"Oldest\"]', 310, 1, '2026-02-02 17:14:23'),
(20, 'CV', 'Coromandel Exp', '12841', 'Kolkata', 'Chennai', '14:00', '17:00', '27h 00m', 850.00, 'Sleeper', 'sleeper', '[\"Fast\"]', 300, 1, '2026-02-02 17:14:23'),
(21, 'SC', 'Secunderabad Exp', '12703', 'Kolkata', 'Hyderabad', '07:00', '09:00', '26h 00m', 780.00, 'Sleeper', 'sleeper', '[\"Pantry\"]', 290, 1, '2026-02-02 17:14:23'),
(22, 'JP', 'Jaipur SF', '12986', 'Delhi', 'Jaipur', '17:00', '22:00', '5h 00m', 300.00, 'Sleeper', 'sleeper', '[\"Seating\"]', 400, 1, '2026-02-02 17:14:23'),
(23, 'JP', 'Jaipur SF', '12986', 'Delhi', 'Jaipur', '17:00', '22:00', '5h 00m', 800.00, 'AC Chair Car', 'ac1', '[\"AC\"]', 200, 1, '2026-02-02 17:14:23'),
(24, 'GD', 'Garib Rath', '12909', 'Mumbai', 'Delhi', '16:00', '09:00', '17h 00m', 1100.00, 'AC 3-Tier', 'ac3', '[\"Low Cost AC\"]', 400, 1, '2026-02-02 17:14:23'),
(25, 'GD', 'Garib Rath', '12204', 'Amritsar', 'Delhi', '04:00', '11:00', '7h 00m', 600.00, 'AC Chair Car', 'ac3', '[\"Low Cost\"]', 300, 1, '2026-02-02 17:14:23'),
(26, 'VB', 'Vande Bharat', '20901', 'Mumbai', 'Gandhinagar', '06:00', '12:30', '6h 30m', 1500.00, 'AC Chair Car', 'ac1', '[\"Premium\", \"Meals\"]', 200, 1, '2026-02-02 17:14:23'),
(27, 'VB', 'Vande Bharat', '22436', 'Delhi', 'Varanasi', '06:00', '14:00', '8h 00m', 1800.00, 'AC Chair Car', 'ac1', '[\"Premium\"]', 200, 1, '2026-02-02 17:14:23'),
(28, 'VB', 'Vande Bharat', '20607', 'Chennai', 'Mysore', '05:50', '12:30', '6h 40m', 1400.00, 'AC Chair Car', 'ac1', '[\"Premium\"]', 200, 1, '2026-02-02 17:14:23'),
(29, 'VB', 'Vande Bharat', '20172', 'Pune', 'Mumbai', '14:30', '17:30', '3h 00m', 900.00, 'AC Chair Car', 'ac1', '[\"Short Haul\"]', 200, 1, '2026-02-02 17:14:23'),
(30, 'VB', 'Vande Bharat', '22226', 'Mumbai', 'Solapur', '16:00', '22:30', '6h 30m', 1300.00, 'AC Chair Car', 'ac1', '[\"Premium\"]', 180, 1, '2026-02-02 17:14:23'),
(31, 'HM', 'Himalayan Queen', '52455', 'Kalka', 'Shimla', '12:00', '17:00', '5h 00m', 400.00, 'Sleeper', 'sleeper', '[\"Toy Train\"]', 100, 1, '2026-02-02 17:14:23'),
(32, 'DQ', 'Deccan Queen', '12123', 'Mumbai', 'Pune', '17:00', '20:30', '3h 30m', 500.00, 'AC Chair Car', 'ac1', '[\"Dining Car\"]', 250, 1, '2026-02-02 17:14:23'),
(33, 'DD', 'Double Decker', '12932', 'Ahmedabad', 'Mumbai', '06:00', '13:00', '7h 00m', 600.00, 'AC Chair Car', 'ac3', '[\"Double Floor\"]', 400, 1, '2026-02-02 17:14:23'),
(34, 'DD', 'Double Decker', '22626', 'Bangalore', 'Chennai', '14:30', '20:30', '6h 00m', 650.00, 'AC Chair Car', 'ac3', '[\"Double Floor\"]', 380, 1, '2026-02-02 17:14:23'),
(35, 'TE', 'Tejas Express', '82902', 'Ahmedabad', 'Mumbai', '06:40', '13:10', '6h 30m', 1600.00, 'AC Chair Car', 'ac1', '[\"Luxury\"]', 150, 1, '2026-02-02 17:14:23'),
(36, 'MA', 'Maharaja Exp', '00001', 'Delhi', 'Mumbai', '09:00', '09:00', '7 Days', 500000.00, 'AC 1st Class', 'ac1', '[\"Ultra Luxury\"]', 50, 1, '2026-02-02 17:14:23'),
(37, 'PO', 'Palace on Wheels', '00002', 'Delhi', 'Delhi', '18:00', '06:00', '7 Days', 450000.00, 'AC 1st Class', 'ac1', '[\"Royal Rajasthan\"]', 40, 1, '2026-02-02 17:14:23'),
(38, 'GR', 'Golden Chariot', '00003', 'Bangalore', 'Goa', '10:00', '10:00', '6 Days', 350000.00, 'AC 1st Class', 'ac1', '[\"South India\"]', 40, 1, '2026-02-02 17:14:23'),
(39, 'KS', 'Kashi Mahakal', '00004', 'Varanasi', 'Indore', '14:00', '08:00', '18h 00m', 1500.00, 'AC 3-Tier', 'ac3', '[\"Spiritual\"]', 200, 1, '2026-02-02 17:14:23'),
(40, 'BR', 'Bharat Gaurav', '00005', 'Delhi', 'Katra', '08:00', '20:00', '12h 00m', 2000.00, 'AC 3-Tier', 'ac3', '[\"Tourist\"]', 300, 1, '2026-02-02 17:14:23'),
(41, 'IC', 'Intercity', '12127', 'Mumbai', 'Pune', '06:40', '09:57', '3h 17m', 150.00, 'Sleeper', 'sleeper', '[\"Seating\"]', 400, 1, '2026-02-02 17:14:23'),
(42, 'IC', 'Intercity', '12472', 'Delhi', 'Mumbai', '13:00', '06:00', '17h 00m', 2500.00, 'AC 2-Tier', 'ac2', '[\"Sleeper\"]', 200, 1, '2026-02-02 17:14:23'),
(43, 'AP', 'Ashram Exp', '12916', 'Delhi', 'Ahmedabad', '15:20', '07:00', '15h 40m', 700.00, 'Sleeper', 'sleeper', '[\"Popular\"]', 300, 1, '2026-02-02 17:14:23'),
(44, 'AP', 'Ashram Exp', '12916', 'Delhi', 'Ahmedabad', '15:20', '07:00', '15h 40m', 1900.00, 'AC 2-Tier', 'ac2', '[\"Popular\"]', 120, 1, '2026-02-02 17:14:23'),
(45, 'SK', 'Sampark Kranti', '12217', 'Kochuveli', 'Chandigarh', '09:15', '16:00', '54h 45m', 1100.00, 'Sleeper', 'sleeper', '[\"Long Haul\"]', 250, 1, '2026-02-02 17:14:23'),
(46, 'SK', 'Sampark Kranti', '12217', 'Kochuveli', 'Chandigarh', '09:15', '16:00', '54h 45m', 3500.00, 'AC 2-Tier', 'ac2', '[\"Long Haul\"]', 100, 1, '2026-02-02 17:14:23'),
(47, 'KL', 'Konkan Kanya', '10111', 'Mumbai', 'Goa', '23:05', '10:45', '11h 40m', 600.00, 'Sleeper', 'sleeper', '[\"Scenic\"]', 300, 1, '2026-02-02 17:14:23'),
(48, 'KL', 'Konkan Kanya', '10111', 'Mumbai', 'Goa', '23:05', '10:45', '11h 40m', 1600.00, 'AC 3-Tier', 'ac3', '[\"Scenic\"]', 150, 1, '2026-02-02 17:14:23'),
(49, 'JS', 'Jan Shatabdi', '12059', 'Kota', 'Delhi', '06:15', '12:30', '6h 15m', 550.00, 'AC Chair Car', 'ac3', '[\"Day Trip\"]', 300, 1, '2026-02-02 17:14:23'),
(50, 'JS', 'Jan Shatabdi', '12023', 'Howrah', 'Patna', '14:05', '22:15', '8h 10m', 600.00, 'AC Chair Car', 'ac3', '[\"Day Trip\"]', 280, 1, '2026-02-02 17:14:23'),
(51, 'JS', 'Jan Shatabdi', '12081', 'Calicut', 'Kannur', '14:00', '15:30', '1h 30m', 200.00, 'Sleeper', 'sleeper', '[\"Seating\"]', 400, 1, '2026-02-02 17:14:23'),
(52, 'MD', 'Mandovi Exp', '10103', 'Mumbai', 'Goa', '07:10', '18:45', '11h 35m', 600.00, 'Sleeper', 'sleeper', '[\"Day Journey\"]', 300, 1, '2026-02-02 17:14:23'),
(53, 'MD', 'Mandovi Exp', '10103', 'Mumbai', 'Goa', '07:10', '18:45', '11h 35m', 1600.00, 'AC 3-Tier', 'ac3', '[\"Day Journey\"]', 150, 1, '2026-02-02 17:14:23'),
(54, 'UD', 'Udyan Exp', '11301', 'Mumbai', 'Bangalore', '08:10', '06:00', '21h 50m', 700.00, 'Sleeper', 'sleeper', '[\"Popular\"]', 300, 1, '2026-02-02 17:14:23'),
(55, 'UD', 'Udyan Exp', '11301', 'Mumbai', 'Bangalore', '08:10', '06:00', '21h 50m', 1900.00, 'AC 3-Tier', 'ac3', '[\"Popular\"]', 150, 1, '2026-02-02 17:14:23'),
(56, 'NE', 'Netravati Exp', '16345', 'Mumbai', 'Trivandrum', '11:40', '18:00', '30h 20m', 850.00, 'Sleeper', 'sleeper', '[\"Coastal\"]', 280, 1, '2026-02-02 17:14:23'),
(57, 'NE', 'Netravati Exp', '16345', 'Mumbai', 'Trivandrum', '11:40', '18:00', '30h 20m', 2400.00, 'AC 2-Tier', 'ac2', '[\"Coastal\"]', 120, 1, '2026-02-02 17:14:23'),
(58, 'CS', 'Coastal Exp', '17229', 'Trivandrum', 'Hyderabad', '07:00', '08:00', '25h 00m', 750.00, 'Sleeper', 'sleeper', '[\"Slow\"]', 300, 1, '2026-02-02 17:14:23'),
(59, 'MP', 'Matsyagandha', '12619', 'Mumbai', 'Mangalore', '15:20', '07:30', '16h 10m', 650.00, 'Sleeper', 'sleeper', '[\"Konkan\"]', 300, 1, '2026-02-02 17:14:23'),
(60, 'MP', 'Matsyagandha', '12619', 'Mumbai', 'Mangalore', '15:20', '07:30', '16h 10m', 1700.00, 'AC 3-Tier', 'ac3', '[\"Konkan\"]', 150, 1, '2026-02-02 17:14:23'),
(61, 'NZ', 'Nizamuddin Exp', '12415', 'Indore', 'Delhi', '16:00', '06:00', '14h 00m', 600.00, 'Sleeper', 'sleeper', '[\"Night\"]', 300, 1, '2026-02-02 17:14:23'),
(62, 'NZ', 'Nizamuddin Exp', '12415', 'Indore', 'Delhi', '16:00', '06:00', '14h 00m', 1600.00, 'AC 3-Tier', 'ac3', '[\"Night\"]', 150, 1, '2026-02-02 17:14:23'),
(63, 'PB', 'Punjab Mail', '12137', 'Mumbai', 'Ferozepur', '19:35', '05:00', '33h 25m', 900.00, 'Sleeper', 'sleeper', '[\"Historic\"]', 280, 1, '2026-02-02 17:14:23'),
(64, 'PB', 'Punjab Mail', '12137', 'Mumbai', 'Ferozepur', '19:35', '05:00', '33h 25m', 2500.00, 'AC 2-Tier', 'ac2', '[\"Historic\"]', 120, 1, '2026-02-02 17:14:23'),
(65, 'ME', 'Mewar Exp', '12964', 'Udaipur', 'Delhi', '18:30', '07:00', '12h 30m', 550.00, 'Sleeper', 'sleeper', '[\"Night\"]', 300, 1, '2026-02-02 17:14:23');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password_hash`, `created_at`, `is_active`) VALUES
(7, 'krish tarpara', 'tarparakrish0903@gmail.com', '7201036881', 'pbkdf2:sha256:1000000$5Mf9jOQftwR1dDg6$42fe4f1684b6d3f738a66394d7147c5a3484d3915ed4e5171561daa7ce9381b9', '2026-02-18 11:41:06', 1),
(8, 'Meet Gojariya', 'meetgojariya214@gmail.com', '9825057315', 'pbkdf2:sha256:1000000$KR0XulzzMl9uAlUs$f8567113e22d42e3340b29a4e627326517f74ef7a6c0486d717bb911e38c4ef0', '2026-02-18 11:46:45', 1),
(9, 'Khush Borsania', 'khushborsania1276@gmail.com', '7984491631', 'pbkdf2:sha256:1000000$xwhMG3vBVQ3ucCoB$aa887b7d0dcc16a4c8c7abeb531506279dbe8d6fef4ad6b789b0a619cdfe2e38', '2026-02-18 13:38:01', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_admin_active` (`is_active`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `booking_reference` (`booking_reference`),
  ADD KEY `idx_bookings_user` (`user_id`),
  ADD KEY `idx_bookings_type` (`booking_type`),
  ADD KEY `idx_bookings_status` (`status`),
  ADD KEY `idx_bookings_travel_date` (`travel_date`);

--
-- Indexes for table `flights`
--
ALTER TABLE `flights`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_flights_origin_dest` (`origin`,`destination`),
  ADD KEY `idx_flights_category` (`category`),
  ADD KEY `idx_flights_price` (`price`);

--
-- Indexes for table `hotels`
--
ALTER TABLE `hotels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_hotels_city` (`city`),
  ADD KEY `idx_hotels_price` (`price_per_night`),
  ADD KEY `idx_hotels_rating` (`rating`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_packages_category` (`category`),
  ADD KEY `idx_packages_destination` (`destination`),
  ADD KEY `idx_packages_price` (`price`);

--
-- Indexes for table `saved`
--
ALTER TABLE `saved`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_saved_item` (`user_id`,`item_type`,`item_id`),
  ADD KEY `idx_saved_user` (`user_id`),
  ADD KEY `idx_saved_type` (`item_type`);

--
-- Indexes for table `trains`
--
ALTER TABLE `trains`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_trains_origin_dest` (`origin`,`destination`),
  ADD KEY `idx_trains_category` (`category`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_users_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `flights`
--
ALTER TABLE `flights`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `hotels`
--
ALTER TABLE `hotels`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `saved`
--
ALTER TABLE `saved`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `trains`
--
ALTER TABLE `trains`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
