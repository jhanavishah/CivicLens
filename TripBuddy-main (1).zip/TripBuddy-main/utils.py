"""
Utility functions for TripBuddy application
Contains helper functions for OTP, email, password hashing, and date parsing
"""

import random
import string
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from werkzeug.security import generate_password_hash
from config import SMTP_SERVER, SMTP_PORT, SMTP_USER, SMTP_PASS, OTP_LENGTH


# ==================== OTP FUNCTIONS ====================
def generate_otp(length=OTP_LENGTH):
    """Generate a random OTP of specified length"""
    return ''.join(random.choices(string.digits, k=length))


def send_otp_email(email, otp):
    """Send OTP via email using SMTP"""
    try:
        subject = 'Your TripBuddy Verification Code'
        body = f'Your OTP code is: {otp}\n\nThis code is valid for 2 minutes.'
        msg = MIMEMultipart()
        msg['From'] = SMTP_USER
        msg['To'] = email
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))

        print(f'Attempting to send OTP email to {email}...')
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            print('SMTP connection established, attempting login...')
            server.login(SMTP_USER, SMTP_PASS)
            print('SMTP login successful, sending email...')
            server.sendmail(SMTP_USER, email, msg.as_string())
            print('Email sent successfully!')
    except smtplib.SMTPAuthenticationError as e:
        print(f'SMTP Authentication Error: {e}')
        raise Exception('Email authentication failed. Please check SMTP credentials.')
    except smtplib.SMTPException as e:
        print(f'SMTP Error: {e}')
        raise Exception(f'Failed to send email: {str(e)}')
    except Exception as e:
        print(f'General Error sending email: {e}')
        raise Exception(f'Error sending email: {str(e)}')


# ==================== PASSWORD FUNCTIONS ====================
def generate_admin_password_hash(password):
    """
    Generate password hash for admin users
    Usage: generate_admin_password_hash('your_password')
    """
    return generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)


# ==================== DATE PARSING FUNCTIONS ====================
def parse_single_date(date_part):
    """
    Parse a single date string and return YYYY-MM-DD format
    Handles various date formats:
    - "Wed 19 Feb" (from flatpickr)
    - "2026-02-19" (YYYY-MM-DD)
    - ISO format dates
    """
    date_part = date_part.strip()
    
    # Format 1: "Wed 19 Feb" (from flatpickr)
    if len(date_part.split()) == 3:
        parts = date_part.split()
        day = parts[1]
        month = parts[2]
        year = datetime.now().year
        try:
            parsed_date = datetime.strptime(f"{day} {month} {year}", "%d %b %Y")
            if parsed_date < datetime.now():
                parsed_date = datetime.strptime(f"{day} {month} {year + 1}", "%d %b %Y")
            return parsed_date.strftime('%Y-%m-%d')
        except Exception as e:
            print(f"Error parsing flatpickr date '{date_part}': {e}")
    
    # Format 2: Already in YYYY-MM-DD format
    if '-' in date_part and len(date_part) == 10:
        try:
            datetime.strptime(date_part, '%Y-%m-%d')
            return date_part
        except Exception as e:
            print(f"Error parsing YYYY-MM-DD date '{date_part}': {e}")
    
    # Format 3: Try ISO format
    try:
        parsed_date = datetime.fromisoformat(date_part.split('T')[0])
        return parsed_date.strftime('%Y-%m-%d')
    except Exception as e:
        print(f"Error parsing ISO date '{date_part}': {e}")
    
    return None


def parse_date_range(date_str):
    """
    Parse date or date range string
    Returns tuple: (travel_date, return_date)
    """
    travel_date = None
    return_date = None
    
    if not date_str:
        return (datetime.now().strftime('%Y-%m-%d'), None)
    
    try:
        # Check if date range (for hotels: "Wed 19 Feb - Fri 21 Feb")
        if ' - ' in date_str:
            parts = date_str.split(' - ')
            travel_date = parse_single_date(parts[0])
            return_date = parse_single_date(parts[1])
            print(f"Parsed date range: {travel_date} to {return_date}")
        else:
            # Single date
            travel_date = parse_single_date(date_str)
            print(f"Parsed single date: {travel_date}")
                
    except Exception as e:
        print(f"Error in date parsing block '{date_str}': {e}")
    
    # Default to today if no valid date
    if not travel_date:
        travel_date = datetime.now().strftime('%Y-%m-%d')
        print(f"Warning: Using default date (today) as no valid date provided. Input was: {date_str}")
    
    return (travel_date, return_date)
